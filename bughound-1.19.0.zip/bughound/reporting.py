"""Render scan results to JSON and Markdown reports."""

from __future__ import annotations

from collections import Counter

from .models import Category, ScanResult, Severity

SEVERITY_ORDER = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW, Severity.INFO]


def to_json(result: ScanResult) -> str:
    return result.model_dump_json(indent=2)


def _severity_badge(sev: Severity) -> str:
    return {
        Severity.CRITICAL: "CRITICAL",
        Severity.HIGH: "HIGH",
        Severity.MEDIUM: "MEDIUM",
        Severity.LOW: "LOW",
        Severity.INFO: "INFO",
    }[sev]


def _render_recon_md(recon: dict) -> list[str]:
    """Render the structured recon dict as a clean Markdown section.

    Returns a list of lines (without trailing newline) to splice into the
    report. Empty if no recon data was collected.
    """
    if not recon:
        return []

    lines: list[str] = ["## Reconnaissance (attack-surface overview)", ""]

    # Subdomains
    subdomains = recon.get("subdomains") or []
    if subdomains:
        lines.append(f"### Subdomains discovered ({len(subdomains)})")
        lines.append("")
        lines.append("_Via Certificate Transparency logs and active DNS brute force._")
        lines.append("")
        # Render as a fenced list; trim very long lists to keep the report readable.
        shown = subdomains[:60]
        for s in shown:
            lines.append(f"- `{s}`")
        if len(subdomains) > len(shown):
            lines.append(f"- ... and {len(subdomains) - len(shown)} more")
        lines.append("")

    # Subdomain takeover candidates
    takeovers = recon.get("subdomain_takeover_candidates") or []
    if takeovers:
        lines.append(f"### ⚠ Possible subdomain takeovers ({len(takeovers)})")
        lines.append("")
        lines.append("| Subdomain | CNAME | Platform |")
        lines.append("|---|---|---|")
        for t in takeovers[:30]:
            lines.append(f"| `{t.get('subdomain')}` | `{t.get('cname')}` | {t.get('service')} |")
        lines.append("")
        lines.append(
            "_Flagged from DNS evidence only (dangling CNAME pattern); confirm by hand "
            "or add the host to scope and re-scan before reporting as exploitable._"
        )
        lines.append("")

    # Favicon hash (Shodan/Censys pivot)
    favicon_hash_val = recon.get("favicon_hash")
    if favicon_hash_val is not None:
        lines.append("### Favicon hash")
        lines.append("")
        lines.append(
            f"`http.favicon.hash:{favicon_hash_val}` -- search this on Shodan/Censys to find "
            "other hosts serving the identical favicon."
        )
        lines.append("")

    # WHOIS / RDAP
    whois = recon.get("whois") or {}
    if whois:
        lines.append("### WHOIS / registration")
        lines.append("")
        for label, key in (
            ("Registrar", "registrar"),
            ("Registered", "created"),
            ("Expires", "expires"),
            ("Registrant org", "registrant_org"),
            ("Nameservers", "nameservers"),
        ):
            val = whois.get(key)
            if not val:
                continue
            if isinstance(val, list):
                val = ", ".join(val[:6])
            lines.append(f"- **{label}:** {val}")
        lines.append("")

    # Wayback Machine historical URLs
    wayback = recon.get("wayback_urls") or []
    if wayback:
        lines.append(f"### Historical URLs (Wayback Machine, {len(wayback)} shown)")
        lines.append("")
        for u in wayback[:40]:
            lines.append(f"- `{u}`")
        if len(wayback) > 40:
            lines.append(f"- ... and {len(wayback) - 40} more")
        lines.append("")
    wayback_interesting = recon.get("wayback_interesting_urls") or []
    if wayback_interesting:
        lines.append("### ⚠ Archived backup/config-looking URLs")
        lines.append("")
        for u in wayback_interesting[:30]:
            lines.append(f"- `{u}`")
        lines.append("")

    # DNS records
    dns = recon.get("dns_records") or {}
    if dns:
        lines.append("### DNS records")
        lines.append("")
        lines.append("| Type | Values |")
        lines.append("|---|---|")
        for rtype, values in dns.items():
            v = ", ".join(str(v) for v in values[:6]) if values else "-"
            if len(values) > 6:
                v += f", ... (+{len(values) - 6})"
            lines.append(f"| {rtype} | {v} |")
        lines.append("")

    # Email security
    email_sec = recon.get("email_security") or {}
    if email_sec:
        lines.append("### Email authentication posture")
        lines.append("")
        lines.append(f"- **SPF:** `{email_sec.get('spf') or '(none)'}`")
        lines.append(f"- **DMARC:** `{email_sec.get('dmarc') or '(none)'}`")
        for issue in email_sec.get("issues", []):
            lines.append(f"- ⚠ {issue}")
        lines.append("")

    # Tech stack
    stack = recon.get("tech_stack") or {}
    if stack:
        lines.append("### Technology stack")
        lines.append("")
        lines.append("| Category | Products |")
        lines.append("|---|---|")
        for cat, prods in sorted(stack.items()):
            lines.append(f"| {cat} | {', '.join(prods)} |")
        lines.append("")

    # WAF
    waf = recon.get("waf")
    if waf:
        lines.append("### WAF / CDN")
        lines.append("")
        lines.append(f"Fronting security layer: **{waf}**")
        lines.append("")
    elif recon.get("waf") is None and "waf" in recon:
        lines.append("### WAF / CDN")
        lines.append("")
        lines.append("No WAF / CDN detected via headers.")
        lines.append("")

    # HTTP methods
    methods = recon.get("http_methods") or []
    if methods:
        lines.append("### HTTP methods advertised")
        lines.append("")
        lines.append(f"`{', '.join(methods)}`")
        lines.append("")

    # JS endpoints
    endpoints = recon.get("js_endpoints") or []
    if endpoints:
        lines.append(f"### Endpoints extracted from JavaScript ({len(endpoints)})")
        lines.append("")
        shown = endpoints[:80]
        for e in shown:
            lines.append(f"- `{e}`")
        if len(endpoints) > len(shown):
            lines.append(f"- ... and {len(endpoints) - len(shown)} more")
        lines.append("")

    # Emails
    emails = recon.get("emails") or []
    if emails:
        lines.append(f"### Email addresses harvested ({len(emails)})")
        lines.append("")
        for e in emails[:40]:
            lines.append(f"- `{e}`")
        if len(emails) > 40:
            lines.append(f"- ... and {len(emails) - 40} more")
        lines.append("")

    # Admin paths
    admin = recon.get("admin_paths") or []
    if admin:
        lines.append(f"### Management / admin paths discovered ({len(admin)})")
        lines.append("")
        for p in admin:
            lines.append(f"- `{p}`")
        lines.append("")

    # API docs
    api_docs = recon.get("api_docs") or []
    if api_docs:
        lines.append(f"### API documentation endpoints ({len(api_docs)})")
        lines.append("")
        for p in api_docs:
            lines.append(f"- `{p}`")
        lines.append("")

    # Backup files
    backups = recon.get("backup_files") or []
    if backups:
        lines.append(f"### Backup / versioned files discovered ({len(backups)})")
        lines.append("")
        for p in backups:
            lines.append(f"- `{p}`")
        lines.append("")

    # Sourcemaps
    maps = recon.get("sourcemaps") or []
    if maps:
        lines.append(f"### Exposed source maps ({len(maps)})")
        lines.append("")
        for m in maps:
            lines.append(f"- `{m}`")
        lines.append("")

    # Well-known paths
    wk = recon.get("well_known_paths") or []
    if wk:
        lines.append(f"### Well-known endpoints ({len(wk)})")
        lines.append("")
        for p in wk:
            lines.append(f"- `{p}`")
        lines.append("")

    # robots.txt
    robots = recon.get("robots_txt") or ""
    if robots:
        lines.append("### robots.txt")
        lines.append("")
        lines.append("```")
        lines.append(robots[:2000])
        lines.append("```")
        lines.append("")

    # security.txt
    sec_txt = recon.get("security_txt") or ""
    if sec_txt:
        lines.append("### security.txt")
        lines.append("")
        lines.append("```")
        lines.append(sec_txt[:2000])
        lines.append("```")
        lines.append("")

    # Sitemap URLs
    sitemap = recon.get("sitemap_urls") or []
    if sitemap:
        lines.append(f"### URLs from sitemap.xml ({len(sitemap)})")
        lines.append("")
        shown = sitemap[:60]
        for u in shown:
            lines.append(f"- `{u}`")
        if len(sitemap) > len(shown):
            lines.append(f"- ... and {len(sitemap) - len(shown)} more")
        lines.append("")

    # Discovered URLs (aggregated by robots/sitemap module)
    discovered = recon.get("discovered_urls") or []
    if discovered:
        lines.append(f"### Discovered URLs (well-known + sitemap, {len(discovered)})")
        lines.append("")
        shown = discovered[:60]
        for u in shown:
            lines.append(f"- `{u}`")
        if len(discovered) > len(shown):
            lines.append(f"- ... and {len(discovered) - len(shown)} more")
        lines.append("")

    if len(lines) == 2:  # only the section heading
        lines.append("_No structured reconnaissance data was collected._")
        lines.append("")
    return lines


def to_markdown(result: ScanResult) -> str:
    lines: list[str] = []
    t = result.target
    lines.append(f"# Security assessment report: {t.host}")
    lines.append("")
    lines.append(f"- **Target:** {result.config.target_url}")
    lines.append(f"- **Authorization:** {t.authorization_note}")
    lines.append(f"- **Started:** {result.started_at.isoformat()}")
    if result.finished_at:
        lines.append(f"- **Finished:** {result.finished_at.isoformat()}")
    lines.append(f"- **Mode:** {result.config.mode or ('aggressive (active exploitation)' if result.config.aggressive else 'safe (passive)')}")
    if result.config.aggressive and result.config.exploit:
        lines.append("- **Exploit phase:** enabled (safe, non-destructive impact proofs)")
    if result.config.bruteforce:
        lines.append("- **Credential checks:** default-credential testing enabled (--brute / nuke mode)")
    lines.append(f"- **URLs crawled:** {result.stats.get('urls_crawled', 0)}")
    lines.append(f"- **Injectable targets:** {result.stats.get('injectable_targets', 0)}")
    lines.append("")

    counts = Counter(f.severity for f in result.findings)
    verified = sum(1 for f in result.findings if f.verified)
    exploited = sum(1 for f in result.findings if f.exploit_status == "succeeded")
    fp_verified = result.stats.get("fp_verified", 0)
    fp_flagged = result.stats.get("fp_flagged", 0)
    code_mapped = result.stats.get("code_mapped", 0)

    # Executive summary: the three questions every reader asks first.
    lines.append("## Executive summary")
    lines.append("")
    top_cats = [c for c, _ in Counter(f.category.value for f in result.findings).most_common(3)]
    lines.append(
        f"The scan identified **{len(result.findings)} finding(s)**"
        f" ({counts.get(Severity.CRITICAL, 0)} critical, {counts.get(Severity.HIGH, 0)} high, "
        f"{counts.get(Severity.MEDIUM, 0)} medium, {counts.get(Severity.LOW, 0)} low, "
        f"{counts.get(Severity.INFO, 0)} informational)."
    )
    lines.append(
        f" Of these, **{verified} were verified** with hard evidence and "
        f"**{exploited} were actively exploited** with safe, non-destructive payloads to "
        "demonstrate concrete impact (extracted data, command output, or file contents "
        "captured in this report)."
    )
    if fp_verified or fp_flagged:
        lines.append(
            f" False-positive control experiments (negative controls, repeat consistency, "
            f"baseline cleanliness) were executed on non-exploited findings: "
            f"**{fp_verified} passed clean**, {fp_flagged} were flagged for manual review."
        )
    if code_mapped:
        lines.append(
            f" **{code_mapped} finding(s) were mapped to the exact vulnerable source location** "
            "(file, line and sink excerpt in each finding's 'Vulnerable code location' section)."
        )
    if top_cats:
        lines.append(f" Dominant risk areas: {', '.join(top_cats)}.")
    else:
        lines.append("No vulnerability findings were recorded for this scope and mode.")
    lines.append("")
    if exploited:
        lines.append(
            "**Read this first:** findings marked \u2705 EXPLOITED include the exact payload, a "
            "ready-to-run `curl` reproduction, the verbatim HTTP exchange, and the data the "
            "exploit extracted. Triage can confirm each one in minutes without re-deriving "
            "the attack."
        )
        lines.append("")

    lines.append("## Summary")
    lines.append("")
    lines.append("| Severity | Count | Exploited |")
    lines.append("|---|---|---|")
    for sev in SEVERITY_ORDER:
        sev_exploited = sum(
            1 for f in result.findings if f.severity == sev and f.exploit_status == "succeeded"
        )
        lines.append(f"| {_severity_badge(sev)} | {counts.get(sev, 0)} | {sev_exploited} |")
    lines.append(f"| **Total** | **{len(result.findings)}** | **{exploited}** |")
    lines.append("")

    # Recon section: render before coverage so operators see the attack surface
    # up-front. Skip entirely if no recon modules produced data.
    recon_lines = _render_recon_md(result.recon or {})
    if recon_lines:
        lines.extend(recon_lines)

    # Extracted / leaked / hidden data: aggregate every artefact the scan
    # recovered (DB dumps, secrets, file contents, tool harvests, …).
    extracted_lines = _render_extracted_data_md(result)
    if extracted_lines:
        lines.extend(extracted_lines)

    # Attack plan: the recon-informed planner output (0.7). Empty when no
    # plan was produced (passive scans on empty recon).
    plan_lines = _render_plan_md(result)
    if plan_lines:
        lines.extend(plan_lines)

    # Attack chains: combined-impact findings with full provenance (0.7).
    chain_lines = _render_chains_md(result)
    if chain_lines:
        lines.extend(chain_lines)

    # Objective completion: training-lab targets (0.7.1). Rendered only when
    # a lab objective was detected, so normal reports are untouched.
    obj_lines = _render_objective_md(result)
    if obj_lines:
        lines.extend(obj_lines)

    # Coverage: which classes had findings vs were tested with nothing found.
    lines.append("## Coverage")
    lines.append("")
    tested = set(result.modules_run)
    found_cats = {f.category for f in result.findings}
    lines.append(f"Modules run: {', '.join(sorted(tested)) or 'none'}")
    lines.append("")
    lines.append("Vulnerability classes with findings: "
                 + (", ".join(sorted(c.value for c in found_cats)) or "none"))
    lines.append("")

    if result.errors:
        lines.append("## Notes / errors")
        lines.append("")
        for e in result.errors:
            lines.append(f"- {e}")
        lines.append("")

    lines.append("## Findings")
    lines.append("")
    if not result.findings:
        lines.append("No findings reported.")
        return "\n".join(lines)

    for i, f in enumerate(result.sorted_findings, 1):
        status = "VERIFIED" if f.verified else f"confidence: {f.confidence}"
        if f.exploit_status == "succeeded":
            status += " \u2705 EXPLOITED"
        elif f.exploit_status == "attempted":
            status += " (exploit attempted)"
        lines.append(f"### {i}. [{_severity_badge(f.severity)}] {f.title}")
        lines.append("")
        lines.append(f"- **Class:** {f.category.value}")
        lines.append(f"- **URL:** {f.url}")
        if f.injection_point:
            lines.append(f"- **Injection point:** `{f.injection_point}`")
        lines.append(f"- **Status:** {status}")
        if f.cwe:
            lines.append(f"- **CWE:** {f.cwe}")
        lines.append(f"- **Module:** {f.module}")
        if f.chain_of:
            lines.append(f"- **Attack chain:** `{f.chain_label}` -- composed from {len(f.chain_of)} finding(s)")
        lines.append("")
        if f.chain_note:
            lines.append(f"**Chain narrative.** {f.chain_note}")
            lines.append("")
        if f.description:
            lines.append(f"**Description.** {f.description}")
            lines.append("")
        lines.extend(_render_code_location_md(f))
        if f.impact:
            lines.append(f"**Impact.** {f.impact}")
            lines.append("")
        if f.evidence:
            lines.append("**Detection evidence.**")
            lines.append("")
            lines.append("```")
            lines.append(f.evidence)
            if f.request:
                lines.append("")
                lines.append(f.request)
            if f.response_excerpt:
                lines.append("")
                lines.append("--- response excerpt ---")
                lines.append(f.response_excerpt)
            lines.append("```")
            lines.append("")
        lines.extend(_render_poc_md(f))
        lines.extend(_render_verification_md(f))
        if f.remediation:
            lines.append(f"**Remediation.** {f.remediation}")
            lines.append("")
        if f.references:
            lines.append("**References.** " + ", ".join(f.references))
            lines.append("")
        lines.extend(_render_bounty_md(f))

    lines.extend(_render_methodology_md(result))
    return "\n".join(lines)


def _render_extracted_data_md(result: ScanResult) -> list[str]:
    """Aggregate every piece of leaked / extracted / hidden data recovered.

    Sources:
    - ``Finding.extracted_data`` (exploit proofs, tool harvests, secrets)
    - recon keys that hold sensitive artefacts (emails, backup files,
      sourcemaps, API docs, secrets-like strings)
    """
    buckets: list[tuple[str, str, list[str]]] = []  # (source, title, items)

    for f in result.findings:
        items = [str(x) for x in (f.extracted_data or []) if str(x).strip()]
        if not items:
            continue
        source = f.module or f.category.value
        title = f.title
        buckets.append((source, title, items))

    recon = result.recon or {}
    recon_sensitive_keys = (
        ("emails", "Harvested email addresses"),
        ("backup_files", "Exposed backup / archive files"),
        ("sourcemaps", "Exposed JavaScript source maps"),
        ("api_docs", "Exposed API documentation paths"),
        ("admin_paths", "Discovered admin / console paths"),
        ("js_endpoints", "Endpoints extracted from JavaScript"),
        ("wayback_interesting_urls", "Archived backup/config-looking URLs"),
        ("secrets", "Secrets / tokens from recon"),
        ("leaked_data", "Other leaked data (recon)"),
        ("database_dumps", "Database dumps / table extracts"),
        ("file_contents", "Retrieved file contents"),
    )
    for key, label in recon_sensitive_keys:
        raw = recon.get(key)
        if not raw:
            continue
        if isinstance(raw, list):
            items = [str(x) for x in raw if str(x).strip()]
        elif isinstance(raw, dict):
            items = [f"{k}: {v}" for k, v in raw.items()]
        else:
            items = [str(raw)]
        if items:
            buckets.append(("recon", label, items))

    if not buckets:
        return []

    lines: list[str] = [
        "## Extracted / leaked / hidden data",
        "",
        "This section consolidates **all data the scan recovered from the target** "
        "(database rows, command output, file contents, secrets, emails, backup "
        "paths, tool harvests, etc.). Use it as the single place to review what "
        "was pulled out of scope.",
        "",
    ]

    total_items = sum(len(items) for _, _, items in buckets)
    lines.append(f"**{len(buckets)} source(s), {total_items} artefact(s) total.**")
    lines.append("")

    for source, title, items in buckets:
        lines.append(f"### [{source}] {title}")
        lines.append("")
        lines.append("```")
        shown = items[:80]
        for item in shown:
            # Keep lines readable; truncate very long blobs
            text = item if len(item) <= 500 else item[:500] + "…"
            lines.append(text)
        if len(items) > len(shown):
            lines.append(f"… and {len(items) - len(shown)} more")
        lines.append("```")
        lines.append("")

    return lines


def _render_plan_md(result: ScanResult) -> list[str]:
    """Render the recon-informed attack plan (planner persona output)."""
    plan = result.plan or {}
    if not plan:
        return []
    out: list[str] = ["## Attack plan", ""]
    out.append(
        "Produced by the attack-planner after the recon phase: what the observed "
        "attack surface implies for the hunting squads that ran next."
    )
    out.append("")
    focus = plan.get("focus_areas") or []
    if focus:
        out.append("**Focus areas**")
        out.append("")
        out.append("| Area | Why it matters |")
        out.append("|---|---|")
        for f in focus:
            out.append(f"| {f.get('area', '')} | {f.get('why', '')} |")
        out.append("")
    stats = plan.get("surface_stats") or {}
    if stats:
        rendered = ", ".join(f"{k.replace('_', ' ')}: {v}" for k, v in stats.items())
        out.append(f"**Surface statistics:** {rendered}.")
        out.append("")
    waf = plan.get("waf") or {}
    if waf:
        out.append(f"**WAF:** {waf.get('name', '')} -- {waf.get('advice', '')}")
        out.append("")
    tech_notes = plan.get("tech_notes") or []
    if tech_notes:
        out.append("**Tech-specific notes**")
        out.append("")
        for note in tech_notes:
            out.append(f"- {note}")
        out.append("")
    hints = plan.get("hints") or []
    if hints:
        for h in hints:
            out.append(f"- {h}")
        out.append("")
    return out


def _render_objective_md(result: ScanResult) -> list[str]:
    """Objective-completion section for training-lab targets (0.7.1)."""
    obj = getattr(result, "objective", None) or {}
    if not obj.get("title"):
        return []
    lines = ["## Objective completion", ""]
    solved_before = obj.get("solved_before")
    solved_after = obj.get("solved_after")
    if solved_after is True:
        status = "SOLVED"
    elif solved_after is None:
        status = "UNKNOWN (status check failed)"
    else:
        status = "NOT SOLVED"
    lines.append(f"- **Lab:** {obj['title']}")
    lines.append(f"- **Objective type:** {obj.get('type', 'training lab')}")
    ladder = obj.get("ladder") or []
    if ladder:
        lines.append("- **Strategy ladder (title + finding driven):** " + " -> ".join(ladder))
    lines.append(
        "- **Status at scan start:** "
        + ("solved" if solved_before else "not solved" if solved_before is False else "unknown")
    )
    lines.append(f"- **Status at scan end:** **{status}**")
    lines.append("")
    if solved_after is True:
        lines.append(
            "The agent **completed the exploit end-to-end**: the vulnerability was "
            "detected, the lab's intended objective was executed (see the attempt "
            "table below for the winning strategy -- payload exploitation, in-browser "
            "dialog proof, credential extraction or forged state changes depending on "
            "the lab class), and the platform's own status banner flipped to "
            "**Solved**. Captured status markup: "
            f"`{obj.get('evidence') or 'widgetcontainer-lab-status is-solved'}`."
        )
    elif solved_after is None:
        lines.append(
            "The lab's status could not be verified (the instance was throttled or "
            "unreachable during the status check). " + str(obj.get("evidence") or "")
        )
    else:
        lines.append(
            "The objective remained open after every solver strategy the agent "
            "knows. The detection and exploit evidence below still stands; see the "
            "attempts list for what was tried."
        )
    lines.append("")
    attempts = obj.get("attempts") or []
    if attempts:
        lines.append("| Attempt | Strategy | Exploit outcome | Lab solved |")
        lines.append("|---|---|---|---|")
        for a in attempts:
            lines.append(
                f"| {a.get('finding', '')} | {a.get('strategy', '')} "
                f"| {a.get('exploit_status', '')} | {'yes' if a.get('lab_solved') else 'no'} |"
            )
        lines.append("")
    return lines


def _render_chains_md(result: ScanResult) -> list[str]:
    """Summary table of the attack chains recorded this scan."""
    chains = [f for f in result.findings if f.chain_of]
    if not chains:
        return []
    out: list[str] = [
        "## Attack chains",
        "",
        "The exploit-chainer combined individually-proven findings into attack chains "
        "whose combined impact exceeds the sum of the parts. Each chain re-uses only "
        "the safe, read-only primitives already exercised by the exploit phase, and "
        "carries full provenance (`chain_of` fingerprints) back to its ingredients.",
        "",
        "| Chain | Result | Severity | Evidence |",
        "|---|---|---|---|",
    ]
    for f in chains:
        verdict = "proven end-to-end" if f.verified else "assembled from verified links"
        out.append(f"| `{f.chain_label}` | {f.title} | {_severity_badge(f.severity)} | {verdict} |")
    out.append("")
    return out


def _render_bounty_md(f) -> list[str]:
    """Triage-ready submission draft for high-impact proven findings.

    The report-generator persona: for every verified/exploited critical or
    high finding, a copy-pasteable bug-bounty submission skeleton built
    from evidence already in the report.
    """
    if f.severity not in (Severity.CRITICAL, Severity.HIGH):
        return []
    if not (f.verified or f.exploit_status == "succeeded" or f.chain_of):
        return []
    return [
        "#### Bounty submission draft",
        "",
        f"**Title:** {f.title}",
        "",
        f"**Severity:** {f.severity.value}" + (f" ({f.cwe})" if f.cwe else ""),
        "",
        f"**Asset:** {f.url}",
        "",
        f"**Summary:** {f.description}",
        "",
        f"**Impact:** {f.impact}",
        "",
        "**Steps to reproduce:** see the reproduction steps / curl one-liner above "
        "(all evidence in this report is captured verbatim and re-runnable).",
        "",
        "",
    ]


def _render_code_location_md(f) -> list[str]:
    """Render the 'where in the code does this happen' section."""
    out: list[str] = ["#### Vulnerable code location", ""]
    if f.code_file and f.code_snippet:
        span = f"lines {f.code_lines[0]}-{f.code_lines[1]}" if f.code_lines else "location approximate"
        out.append(
            f"**Source-mapped sink:** `{f.code_file}` ({span}), inside **{f.code_symbol}**. "
            "The line marked with `->` is where the injectable input reaches the dangerous sink."
        )
        out.append("")
        out.append(f"```{(f.code_file.rsplit('.', 1)[-1] or 'text').lower()}")
        out.append(f.code_snippet)
        out.append("```")
        out.append("")
    elif f.inferred_sink:
        out.append(
            "**Reconstructed sink (black-box evidence).** The application's source code was not "
            "available to this scan, so the vulnerable code pattern below was reconstructed from "
            "observed behaviour -- the input provably reaches a sink of this shape at the listed "
            "injection point (see the detection evidence and raw exchange for the proof)."
        )
        out.append("")
        out.append("```text")
        out.append(f.inferred_sink)
        out.append("```")
        out.append("")
    else:
        return []
    return out


def _render_verification_md(f) -> list[str]:
    """Render the false-positive analysis for one finding."""
    if not f.verification_checks:
        if f.exploit_status == "succeeded":
            return [
                "#### False-positive analysis",
                "",
                "The exploit phase reproduced the vulnerability end-to-end and extracted real data "
                "from the target, which is itself the strongest false-positive disproof: random "
                "page drift, caching artefacts or WAF noise cannot fabricate extracted database "
                "rows, command output or file contents. No separate control experiments were needed.",
                "",
            ]
        return []
    out: list[str] = ["#### False-positive analysis", ""]
    if f.fp_verdict:
        out.append(f.fp_verdict)
        out.append("")
    out.append("| Control experiment | Result | Observed behaviour |")
    out.append("|---|---|---|")
    for c in f.verification_checks:
        mark = "PASS" if c.get("passed") else "FAIL"
        out.append(f"| {c.get('name', '')} | {mark} | {c.get('detail', '')} |")
    out.append("")
    if f.fp_risk:
        if f.fp_risk == "low":
            out.append("**Verdict: LOW false-positive risk** -- every control experiment behaved "
                       "as physics demands: the attack signature appears only for the crafted "
                       "payload and reproduces consistently.")
        else:
            out.append(f"**Verdict: {f.fp_risk.upper()} false-positive risk** -- at least one control "
                       "experiment contradicts the finding. Manual review required before triage.")
        out.append("")
    return out


def _render_poc_md(f) -> list[str]:
    """Render the Proof-of-Exploitation block for a single finding."""
    if f.exploit_status != "succeeded" and not f.poc_curl:
        if f.exploit_status == "attempted" and f.exploit_summary:
            return [
                "#### Exploit phase result",
                "",
                f.exploit_summary,
                "",
            ]
        return []

    out: list[str] = ["#### Proof of exploitation", ""]
    if f.exploit_summary:
        out.append(f.exploit_summary)
        out.append("")
    if f.extracted_data:
        out.append("**Data extracted from the target by the exploit:**")
        out.append("")
        out.append("```")
        for item in f.extracted_data:
            out.append(str(item))
        out.append("```")
        out.append("")
    if f.poc_curl:
        out.append("**Reproduce (copy-paste):**")
        out.append("")
        out.append("```bash")
        out.append(f.poc_curl)
        out.append("```")
        out.append("")
    if f.raw_request:
        out.append("**Raw HTTP exchange:**")
        out.append("")
        out.append("```http")
        out.append(f.raw_request)
        if f.raw_response:
            out.append("")
            out.append(f.raw_response)
        out.append("```")
        out.append("")
    if f.reproduction_steps:
        out.append("**Manual reproduction steps:**")
        out.append("")
        for n, step in enumerate(f.reproduction_steps, 1):
            out.append(f"{n}. {step}")
        out.append("")
    return out


def _render_methodology_md(result: ScanResult) -> list[str]:
    """Appendix: how the results were obtained (reproducibility & trust)."""
    exploited = sum(1 for f in result.findings if f.exploit_status == "succeeded")
    mapped = result.stats.get("code_mapped", 0)
    fp_verified = result.stats.get("fp_verified", 0)
    fp_flagged = result.stats.get("fp_flagged", 0)
    source_note = (
        f"Source mapping was performed against `{result.config.source_dir}`; each mapped finding "
        "cites the vulnerable file, line range and sink excerpt."
        if result.config.source_dir
        else "No source directory was supplied (--source-dir), so findings carry behaviour-derived "
        "sink reconstructions instead of verbatim source lines."
    )
    return [
        "## Methodology & limitations",
        "",
        "1. **Crawl.** Same-origin crawl of the authorized target discovered "
        f"{result.stats.get('urls_crawled', 0)} URL(s) and "
        f"{result.stats.get('injectable_targets', 0)} injectable target(s) (query parameters and forms).",
        "2. **Detection.** Passive recon modules ran first (attack-surface mapping above); "
        "active modules then sent non-destructive probe payloads to detect "
        "injection, XSS, traversal, SSRF and misconfiguration classes.",
        "3. **Exploitation.**"
        + (f" {exploited} finding(s) were re-targeted with safe impact-proof exploits: "
           "read-only SQL extraction, informational command execution (`id`, `uname`), "
           "system-file reads, executable-payload survival checks and loopback fetches. "
           "No data was modified or destroyed, and no denial-of-service techniques were used."
           if exploited else " Disabled or nothing to exploit.") + "",
        "4. **Attack chaining.** The exploit-chainer looked for combinations of findings "
        "whose combined impact exceeds the sum of the parts (traversal->credentials->"
        "takeover, SSRF->internal admin, XSS->session theft, ...). Chains run only in "
        "aggressive mode, re-use proven primitives within the same request budget, and "
        f"are recorded with full provenance: {result.stats.get('chains', 0)} chain(s) recorded.",
        "5. **False-positive verification.** Findings the exploit phase could not prove were "
        "re-tested with control experiments: negative controls (payload with the active "
        "ingredient removed), repeat-consistency probes, baseline-cleanliness checks, fresh "
        "per-check canaries and differential directionality. "
        f"{fp_verified} passed all controls; {fp_flagged} were flagged for manual review. "
        "A succeeded exploit is its own false-positive disproof, so it bypasses this battery.",
        "6. **Code attribution.** " + source_note,
        "7. **Reporting.** Every claim in this report is backed by the captured request/response "
        "evidence shown alongside it. Findings that could not be proven are explicitly labelled "
        "with their confidence (tentative/firm) rather than overclaimed.",
        "",
        "**Limitations.** Automated testing cannot cover business-logic flaws, authenticated "
        "flows without credentials, or client-side-only rendering. Candidates flagged for manual "
        "review should be verified by a human before triage decisions are made.",
        "",
    ]


def category_summary(result: ScanResult) -> dict[str, int]:
    c: Counter[str] = Counter()
    for f in result.findings:
        c[f.category.value] += 1
    return dict(c)


ALL_CATEGORIES = [c.value for c in Category]
